﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTR_MDCS.Models
{
    public class Report
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }

        public Report()
        {

        }

        public Report(DateTime Date)
        {
            this.Date = Date;
        }
    }
}