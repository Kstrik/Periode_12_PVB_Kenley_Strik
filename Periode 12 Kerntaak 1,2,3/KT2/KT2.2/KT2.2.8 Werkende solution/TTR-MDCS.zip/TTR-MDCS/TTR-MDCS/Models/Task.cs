﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTR_MDCS.Models
{
    public class Task
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public int Visit { get; set; }
        public int Research { get; set; }
        public int Conference_call { get; set; }
        public string Status { get; set; }

        public Task()
        {

        }

        public Task(string Description, DateTime Date, int Visit, int Research, int Conference_call, string Status)
        {
            this.Description = Description;
            this.Date = Date;
            this.Visit = Visit;
            this.Research = Research;
            this.Conference_call = Conference_call;
            this.Status = Status;
        }
    }
}