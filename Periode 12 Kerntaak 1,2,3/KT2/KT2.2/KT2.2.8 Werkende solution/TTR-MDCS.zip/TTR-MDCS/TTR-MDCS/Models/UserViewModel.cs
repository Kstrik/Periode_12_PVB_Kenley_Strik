﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTR_MDCS.Models
{
    public class UserViewModel
    {
        public User User { get; set; }
        public bool RememberPassword { get; set; }

        public UserViewModel()
        {

        }

        public UserViewModel(User User, bool RememberPassword)
        {
            this.User = User;
            this.RememberPassword = RememberPassword;
        }
    }
}