﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTR_MDCS.Models
{
    public class Contactperson
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Telephonenumber { get; set; }
        public bool Accountmanager { get; set; }

        public Contactperson()
        {

        }

        public Contactperson(string Name, string Email, string Telephonenumber, bool Accountmanager)
        {
            this.Name = Name;
            this.Email = Email;
            this.Telephonenumber = Telephonenumber;
            this.Accountmanager = Accountmanager;
        }
    }
}