﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTR_MDCS.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Addres { get; set; }
        public string Zipcode { get; set; }
        public string Residence { get; set; }
        public bool Partner { get; set; }

        public Customer()
        {

        }

        public Customer(string Name, string Addres, string Zipcode, string Residence, bool Partner)
        {
            this.Name = Name;
            this.Addres = Addres;
            this.Zipcode = Zipcode;
            this.Residence = Residence;
            this.Partner = Partner;
        }
    }
}