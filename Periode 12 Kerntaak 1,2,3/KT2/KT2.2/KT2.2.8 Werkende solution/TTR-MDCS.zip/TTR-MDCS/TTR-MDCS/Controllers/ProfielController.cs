﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TTR_MDCS.Classes;
using TTR_MDCS.Models;

namespace TTR_MDCS.Controllers
{
    [IsAuthorized(Roles = new string[1] { "Admin" })]
    public class ProfielController : Controller
    {
        //Get method to Profile page
        public ActionResult Index()
        {
            User user = (User)Session["key"];
            return View(user);
        }

        //Post method to Profile page
        [ValidateInput(true)]
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Index(User user)
        {
            if (ModelState.IsValid)
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                UtilityHelper utilityHelper = new UtilityHelper();
                string hashedPassword = utilityHelper.GetHashedValue(user.Password);

                databaseHandler.EditUserPassword(hashedPassword);

                (Session["key"] as User).Password = hashedPassword;

                if (Request.Cookies["TTR.MDCS-Password"] != null)
                {
                    HttpCookie passwordCookie = new HttpCookie("TTR.MDCS-Password");
                    passwordCookie.Value = (Session["key"] as User).Username + "," + (Session["key"] as User).Password + "," + (Session["key"] as User).Email + "," + (Session["key"] as User).Role;
                    passwordCookie.Expires = DateTime.MaxValue;
                    Response.Cookies["TTR.MDCS-Password"].Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(passwordCookie);
                }

                ModelState.AddModelError("Password", "Wachtwoord succesvol gewijzigd!");
            }
            else
            {
                if (user.Password == null || user.Password == "")
                {
                    ModelState.AddModelError("Password", "Invoerveld is leeg!");
                }
                else
                {
                    ModelState.AddModelError("Password", "Wachtwoord is ongeldig!");
                }
            }

            return View((User)Session["key"]);
        }
    }
}