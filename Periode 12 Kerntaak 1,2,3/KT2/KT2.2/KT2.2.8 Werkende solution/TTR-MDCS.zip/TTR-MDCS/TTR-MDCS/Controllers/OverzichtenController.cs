﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TTR_MDCS.Classes;
using TTR_MDCS.Models;

namespace TTR_MDCS.Controllers
{
    [IsAuthorized(Roles = new string[1] { "Admin" })]
    public class OverzichtenController : Controller
    {
        // GET: Overzichten
        public ActionResult Index()
        {
            return View();
        }

        #region Overzichten
        //Get method to OverzichtTaken page
        public ActionResult OverzichtTaken()
        {
            //DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            //databaseHandler.AddTask(new Task("Test", DateTime.Now, 2, 2, 2, "Started", 1, 1));
            //List<Task> tasks = new List<Task> { new Task("Test", DateTime.Now, 2, 2, 2, "Started"), new Task("Test", DateTime.Now, 2, 2, 2, "Started"), new Task("Test", DateTime.Now, 2, 2, 2, "Started"), new Task("Test", DateTime.Now, 2, 2, 2, "Started") };
            Session["selectedContactperson"] = null;
            Session["TaskList"] = null;
            Session["selectedContactperson"] = null;
            Session["searchedContactpersons"] = null;

            return View();
            //return View(tasks);
        }

        //Post method for getting tasks with specific values
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetTasks(string year, string month, string status)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Task> tasks = new List<Task> { };
            if (Session["selectedContactperson"] != null)
            {
                tasks = databaseHandler.GetTasksWithFilter(year, month, status, Convert.ToString((Session["selectedContactperson"] as Contactperson).Id));
            }
            else
            {
                tasks = databaseHandler.GetTasksWithFilter(year, month, status, null);
            }

            string htmlTableContent = "";

            Session["TaskList"] = tasks;

            for (int i = 0; i < tasks.Count; i++)
            {
                htmlTableContent += "<tr id=\"" + tasks[i].Id + "\">";
                htmlTableContent += "<td>" + (i + 1) + "</td>";
                htmlTableContent += "<td>" + tasks[i].Description + "</td>";
                htmlTableContent += "<td>" + tasks[i].Date + "</td>";
                htmlTableContent += "<td>" + (tasks[i].Visit + tasks[i].Research + tasks[i].Conference_call).ToString() + " uur" + "</td>";
                htmlTableContent += "<td>" + tasks[i].Status + "</td>";
                if (!Request.Browser.IsMobileDevice && Session["selectedContactperson"] != null)
                {
                    htmlTableContent += "<td>" + (Session["selectedContactperson"] as Contactperson).Name + "</td>";
                }
                htmlTableContent += "<td><a class=\"" + "fa fa-edit pull-right" + "\" onclick=\"" + "EditTask(" + tasks[i].Id.ToString() + ")" + "\"></a></td>";
                htmlTableContent += "</td>";
            }

            return Json(htmlTableContent, JsonRequestBehavior.AllowGet);
        }

        //Get method to OverzichtKlanten page
        public ActionResult OverzichtKlanten()
        {
            Session["selectedContactperson"] = null;
            Session["CustomerList"] = null;
            Session["selectedContactperson"] = null;
            Session["searchedContactpersons"] = null;

            return View();
        }

        //Post method to OverzichtPartners page
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult OverzichtPartners(string name, string residence)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> customers = new List<Customer> { };
            if (Session["selectedContactperson"] != null)
            {
                customers = databaseHandler.GetCustomersWithFilter(name, residence, Convert.ToString((Session["selectedContactperson"] as Contactperson).Id));
            }
            else
            {
                customers = databaseHandler.GetCustomersWithFilter(name, residence, null);
            }

            string htmlTableContent = "";

            Session["CustomerList"] = customers;

            for (int i = 0; i < customers.Count; i++)
            {
                htmlTableContent += "<tr id=\"" + customers[i].Id + "\">";
                htmlTableContent += "<td>" + (i + 1) + "</td>";
                htmlTableContent += "<td>" + customers[i].Name + "</td>";
                htmlTableContent += "<td>" + customers[i].Addres + "</td>";
                htmlTableContent += "<td>" + customers[i].Zipcode + "</td>";
                htmlTableContent += "<td>" + customers[i].Residence + "</td>";
                if (!Request.Browser.IsMobileDevice && Session["selectedContactperson"] != null)
                {
                    htmlTableContent += "<td>" + (Session["selectedContactperson"] as Contactperson).Name + "</td>";
                }
                htmlTableContent += "<td><a class=\"" + "fa fa-edit pull-right" + "\" onclick=\"" + "EditCustomer(" + customers[i].Id.ToString() + ")" + "\"></a></td>";
                htmlTableContent += "</td>";
            }

            return Json(htmlTableContent, JsonRequestBehavior.AllowGet);
        }

        //Get method to OverzichtPartners page
        public ActionResult OverzichtPartners()
        {
            Session["selectedContactperson"] = null;
            Session["PartnerList"] = null;
            Session["selectedContactperson"] = null;
            Session["searchedContactpersons"] = null;

            return View();
        }

        //Post method for getting partners with specific values
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetPartners(string name, string residence)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> customers = new List<Customer> { };
            if (Session["selectedContactperson"] != null)
            {
                customers = databaseHandler.GetPartnersWithFilter(name, residence, Convert.ToString((Session["selectedContactperson"] as Contactperson).Id));
            }
            else
            {
                customers = databaseHandler.GetPartnersWithFilter(name, residence, null);
            }

            string htmlTableContent = "";

            Session["PartnerList"] = customers;

            for (int i = 0; i < customers.Count; i++)
            {
                htmlTableContent += "<tr id=\"" + customers[i].Id + "\">";
                htmlTableContent += "<td>" + (i + 1) + "</td>";
                htmlTableContent += "<td>" + customers[i].Name + "</td>";
                htmlTableContent += "<td>" + customers[i].Addres + "</td>";
                htmlTableContent += "<td>" + customers[i].Zipcode + "</td>";
                htmlTableContent += "<td>" + customers[i].Residence + "</td>";
                if (!Request.Browser.IsMobileDevice && Session["selectedContactperson"] != null)
                {
                    htmlTableContent += "<td>" + (Session["selectedContactperson"] as Contactperson).Name + "</td>";
                }
                htmlTableContent += "<td><a class=\"" + "fa fa-edit pull-right" + "\" onclick=\"" + "EditPartner(" + customers[i].Id.ToString() + ")" + "\"></a></td>";
                htmlTableContent += "</td>";
            }

            return Json(htmlTableContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for adding a contactperson to the selection
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddContactpersonToSelection(string contactpersonId)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            Contactperson contactperson = databaseHandler.GetContactperson(int.Parse(contactpersonId));

            Session["selectedContactperson"] = contactperson;

            string htmlContent = contactperson.Name;

            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Get method for getting contactpersons
        [AcceptVerbs(HttpVerbs.Get)]
        public JsonResult GetContactpersons()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> contactpersons = new List<Contactperson> { };
            contactpersons = databaseHandler.GetContactpersons();

            string htmlContent = "";

            Session["searchedContactpersons"] = contactpersons;

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + contactpersons[i].Id.ToString() + "\" onclick=\"" + "OnSegmentContactpersonClick(" + contactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + contactpersons[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting contactpersons with a specific name
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetOnlyContactpersonsByName(string name)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> contactpersons = new List<Contactperson> { };
            contactpersons = databaseHandler.GetContactpersonsByName(name);

            string htmlContent = "";

            Session["searchedContactpersons"] = contactpersons;

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + contactpersons[i].Id.ToString() + "\" onclick=\"" + "OnSegmentContactpersonClick(" + contactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + contactpersons[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Taak Bewerking
        //Post method for editing a task with a specific id
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult EditTask(string taskId)
        {
            Session["TaskId"] = taskId;

            //return RedirectToAction("RapportageBekijken", "Rapportages");
            return Json(new { result = "Redirect", url = Url.Action("TaakBewerken", "Overzichten") });
        }

        //Get method to TaakBewerken page
        public ActionResult TaakBewerken()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            Task task = databaseHandler.GetTask(int.Parse((Session["TaskId"] as string)));

            List<Customer> customers = databaseHandler.GetCustomersFromTask(task);
            List<Contactperson> contactpersons = databaseHandler.GetContactpersonsFromTask(task);

            List<Customer> customers2 = databaseHandler.GetCustomersFromTask(task);
            List<Contactperson> contactpersons2 = databaseHandler.GetContactpersonsFromTask(task);

            //Session["TaskId"] = null;

            Session["searchedCustomers"] = null;
            Session["selectedCustomers"] = null;
            Session["searchedContactpersons"] = null;
            Session["selectedContactpersons"] = null;

            Session["previousSelectedCustomers"] = customers2;
            Session["selectedCustomers"] = customers;
            Session["previousSelectedContactpersons"] = contactpersons2;
            Session["selectedContactpersons"] = contactpersons;

            return View(task);
        }

        //Post method to TaakBewerken page
        [ValidateInput(true)]
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult TaakBewerken(Task task)
        {
            if (task.Description == null || task.Description == "")
            {
                ModelState.AddModelError("Omschrijving", "Het veld mag niet leeg zijn!");
            }
            if (task.Date == null)
            {
                ModelState.AddModelError("Datum", "Het veld mag niet leeg zijn!");
            }
            if (!ModelState.IsValidField("Date"))
            {
                ModelState.AddModelError("Datum", "Incorrect!");
            }

            if (task.Description != null && task.Description != "" && ModelState.IsValidField("Date"))
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                Task aquiredTask = databaseHandler.GetTask(int.Parse((Session["TaskId"] as string)));

                databaseHandler.EditTask(task, aquiredTask.Id);

                if (Session["selectedCustomers"] != null)
                {
                    List<Customer> selectedCustomers = (Session["selectedCustomers"] as List<Customer>);
                    List<Customer> removableCustomers = new List<Customer> { };
                    List<Customer> addableCustomers = new List<Customer> { };

                    if (Session["previousSelectedCustomers"] != null)
                    {
                        List<Customer> previousCustomers = (Session["previousSelectedCustomers"] as List<Customer>);

                        for (int i = 0; i < previousCustomers.Count; i++)
                        {
                            if (!selectedCustomers.Contains(previousCustomers[i]))
                            {
                                removableCustomers.Add(previousCustomers[i]);
                            }
                        }

                        for (int i = 0; i < selectedCustomers.Count; i++)
                        {
                            if (!previousCustomers.Contains(selectedCustomers[i]))
                            {
                                addableCustomers.Add(selectedCustomers[i]);
                            }
                        }

                        if(removableCustomers.Count != 0)
                        {
                            databaseHandler.RemoveCustomersFromTask(removableCustomers, aquiredTask);
                        }
                        if (addableCustomers.Count != 0)
                        {
                            databaseHandler.AddCustomersToTaskWithId(addableCustomers, aquiredTask.Id);
                        }
                    }
                    else
                    {
                        databaseHandler.AddCustomersToTaskWithId(selectedCustomers, aquiredTask.Id);
                    }
                }

                if (Session["selectedContactpersons"] != null)
                {
                    List<Contactperson> selectedContactpersons = (Session["selectedContactpersons"] as List<Contactperson>);
                    List<Contactperson> removableContactpersons = new List<Contactperson> { };
                    List<Contactperson> addableContactpersons = new List<Contactperson> { };

                    if (Session["previousSelectedContactpersons"] != null)
                    {
                        List<Contactperson> previousContactpersons = (Session["previousSelectedContactpersons"] as List<Contactperson>);

                        for (int i = 0; i < previousContactpersons.Count; i++)
                        {
                            if (!selectedContactpersons.Contains(previousContactpersons[i]))
                            {
                                removableContactpersons.Add(previousContactpersons[i]);
                            }
                        }

                        for (int i = 0; i < selectedContactpersons.Count; i++)
                        {
                            if (!previousContactpersons.Contains(selectedContactpersons[i]))
                            {
                                addableContactpersons.Add(selectedContactpersons[i]);
                            }
                        }

                        if (removableContactpersons.Count != 0)
                        {
                            databaseHandler.RemoveContactpersonsFromTask(removableContactpersons, aquiredTask);
                        }
                        if (addableContactpersons.Count != 0)
                        {
                            databaseHandler.AddContactpersonsToTaskWithId(addableContactpersons, aquiredTask.Id);
                        }
                    }
                    else
                    {
                        databaseHandler.AddContactpersonsToTaskWithId(selectedContactpersons, aquiredTask.Id);
                    }
                }

                //if (Session["selectedCustomers"] != null)
                //{
                //    databaseHandler.AddCustomersToTask((Session["selectedCustomers"] as List<Customer>), task);
                //}
                //if (Session["selectedContactpersons"] != null)
                //{
                //    databaseHandler.AddContactpersonsToTask((Session["selectedContactpersons"] as List<Contactperson>), task);
                //}

                Session["searchedCustomers"] = null;
                Session["selectedCustomers"] = null;
                Session["previousSelectedCustomers"] = null;
                Session["searchedContactpersons"] = null;
                Session["selectedContactpersons"] = null;
                Session["previousSelectedContactpersons"] = null;

                Session["TaskId"] = null;

                return RedirectToAction("OverzichtTaken", "Overzichten");
            }

            return View(task);
        }

        //Get method for getting the customers that can be searched
        [AcceptVerbs(HttpVerbs.Get)]
        public JsonResult GetSearchableCustomers()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> aquiredCustomers = new List<Customer> { };
            aquiredCustomers = databaseHandler.GetCustomersAndPartners();

            List<Customer> customers = new List<Customer> { };
            if (Session["selectedCustomers"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedCustomers"] as List<Customer>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredCustomers.Count; j++)
                {
                    if (!tempIds.Contains(aquiredCustomers[j].Id))
                    {
                        customers.Add(aquiredCustomers[j]);
                    }
                }
            }
            else
            {
                customers = aquiredCustomers;
            }

            string htmlContent = "";

            Session["searchedCustomers"] = customers;

            for (int i = 0; i < customers.Count; i++)
            {
                string htmlString = "";
                if (customers[i].Partner == true)
                {
                    htmlString = "Partner";
                }
                else
                {
                    htmlString = "Klant";
                }

                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + customers[i].Id.ToString() + "\" onclick=\"" + "OnSegmentCustomerClick(" + customers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + customers[i].Name + "</label>";
                htmlContent += "<label class=\"" + "pull-right" + "\" style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + htmlString + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting customers with a specific name
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetCustomersByName(string name)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> aquiredCustomers = new List<Customer> { };
            aquiredCustomers = databaseHandler.GetCustomersAndPartnersByName(name);

            List<Customer> customers = new List<Customer> { };
            if (Session["selectedCustomers"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedCustomers"] as List<Customer>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredCustomers.Count; j++)
                {
                    if (!tempIds.Contains(aquiredCustomers[j].Id))
                    {
                        customers.Add(aquiredCustomers[j]);
                    }
                }
            }
            else
            {
                customers = aquiredCustomers;
            }

            string htmlContent = "";

            Session["searchedCustomers"] = customers;

            for (int i = 0; i < customers.Count; i++)
            {
                string htmlString = "";
                if (customers[i].Partner == true)
                {
                    htmlString = "Partner";
                }
                else
                {
                    htmlString = "Klant";
                }

                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + customers[i].Id.ToString() + "\" onclick=\"" + "OnSegmentCustomerClick(" + customers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + customers[i].Name + "</label>";
                htmlContent += "<label class=\"" + "pull-right" + "\" style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + htmlString + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for adding a customer item to the selected items
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddSelectedCustomerItem(string customerId)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> selectedCustomers = new List<Customer> { };
            Customer customer = databaseHandler.GetCustomer(int.Parse(customerId));

            if (Session["selectedCustomers"] != null)
            {
                selectedCustomers = (List<Customer>)Session["selectedCustomers"];
                selectedCustomers.Add(customer);
                Session["selectedCustomers"] = selectedCustomers;
            }
            else
            {
                selectedCustomers = new List<Customer> { customer };
                Session["selectedCustomers"] = selectedCustomers;
            }

            string htmlContent = "";

            for (int i = 0; i < selectedCustomers.Count; i++)
            {
                //string htmlString = "";
                //if (selectedCustomers[i].Partner == true)
                //{
                //    htmlString = "Partner";
                //}
                //else
                //{
                //    htmlString = "Klant";
                //}

                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentCustomerClick(" + selectedCustomers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedCustomers[i].Name + "</label>";
                //htmlTableContent += "<label class=\"" + "pull-right" + "\" style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + htmlString + "</label>";
                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedCustomerItem(" + selectedCustomers[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedCustomers[i].Id.ToString() + "\"></span>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting the selected customers
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetSelectedCustomers()
        {
            List<Customer> selectedCustomers = (List<Customer>)Session["selectedCustomers"];

            string htmlContent = "";

            if(Session["selectedCustomers"] != null)
            {
                for (int i = 0; i < selectedCustomers.Count; i++)
                {
                    htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentCustomerClick(" + selectedCustomers[i].Id.ToString() + ")" + "\">";
                    htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                    htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedCustomers[i].Name + "</label>";
                    htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedCustomerItem(" + selectedCustomers[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedCustomers[i].Id.ToString() + "\"></span>";
                    htmlContent += "</div>";
                }
            }

            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for removing a selected item from the selected customer
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult RemoveSelectedCustomerItem(string customerId)
        {
            List<Customer> selectedCustomers = (List<Customer>)Session["selectedCustomers"];

            List<Customer> customers = new List<Customer> { };

            for (int j = 0; j < selectedCustomers.Count; j++)
            {
                if (selectedCustomers[j].Id != int.Parse(customerId))
                {
                    customers.Add(selectedCustomers[j]);
                }
            }

            Session["selectedCustomers"] = customers;

            return Json("", JsonRequestBehavior.AllowGet);
        }

        //Get method for getting the contactpersons that can be searched
        [AcceptVerbs(HttpVerbs.Get)]
        public JsonResult GetSearchableContactpersons()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> aquiredContactpersons = new List<Contactperson> { };
            aquiredContactpersons = databaseHandler.GetContactpersons();

            List<Contactperson> contactpersons = new List<Contactperson> { };
            if (Session["selectedContactpersons"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedContactpersons"] as List<Contactperson>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredContactpersons.Count; j++)
                {
                    if (!tempIds.Contains(aquiredContactpersons[j].Id))
                    {
                        contactpersons.Add(aquiredContactpersons[j]);
                    }
                }
            }
            else
            {
                contactpersons = aquiredContactpersons;
            }

            string htmlContent = "";

            Session["searchedContactpersons"] = contactpersons;

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + contactpersons[i].Id.ToString() + "\" onclick=\"" + "OnSegmentContactpersonClick(" + contactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + contactpersons[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting contactpersons with a specific name
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetContactpersonsByName(string name)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> aquiredContactpersons = new List<Contactperson> { };
            aquiredContactpersons = databaseHandler.GetContactpersonsByName(name);

            List<Contactperson> contactpersons = new List<Contactperson> { };
            if (Session["selectedContactpersons"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedContactpersons"] as List<Contactperson>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredContactpersons.Count; j++)
                {
                    if (!tempIds.Contains(aquiredContactpersons[j].Id))
                    {
                        contactpersons.Add(aquiredContactpersons[j]);
                    }
                }
            }
            else
            {
                contactpersons = aquiredContactpersons;
            }

            string htmlContent = "";

            Session["searchedCustomers"] = contactpersons;

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + contactpersons[i].Id.ToString() + "\" onclick=\"" + "OnSegmentContactpersonClick(" + contactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + contactpersons[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for adding a contactperson item to the selected items
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddSelectedContactpersonItem(string contactpersonId)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> selectedContactpersons = new List<Contactperson> { };
            Contactperson contactperson = databaseHandler.GetContactperson(int.Parse(contactpersonId));

            if (Session["selectedContactpersons"] != null)
            {
                selectedContactpersons = (List<Contactperson>)Session["selectedContactpersons"];
                selectedContactpersons.Add(contactperson);
                Session["selectedContactpersons"] = selectedContactpersons;
            }
            else
            {
                selectedContactpersons = new List<Contactperson> { contactperson };
                Session["selectedContactpersons"] = selectedContactpersons;
            }

            string htmlContent = "";

            for (int i = 0; i < selectedContactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentContactpersonClick(" + selectedContactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedContactpersons[i].Name + "</label>";
                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedContactpersonItem(" + selectedContactpersons[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedContactpersons[i].Id.ToString() + "\"></span>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting the selected contactperson
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetSelectedContactpersons()
        {
            List<Contactperson> selectedContactpersons = (List<Contactperson>)Session["selectedContactpersons"];

            string htmlContent = "";

            if (Session["selectedContactpersons"] != null)
            {
                for (int i = 0; i < selectedContactpersons.Count; i++)
                {
                    htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentContactpersonClick(" + selectedContactpersons[i].Id.ToString() + ")" + "\">";
                    htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                    htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedContactpersons[i].Name + "</label>";
                    htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedContactpersonItem(" + selectedContactpersons[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedContactpersons[i].Id.ToString() + "\"></span>";
                    htmlContent += "</div>";
                }
            }

            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for removing a selected item from the selected contactperson
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult RemoveSelectedContactpersonItem(string contactpersonId)
        {
            List<Contactperson> selectedContactpersons = (List<Contactperson>)Session["selectedContactpersons"];

            List<Contactperson> contactpersons = new List<Contactperson> { };

            for (int j = 0; j < selectedContactpersons.Count; j++)
            {
                if (selectedContactpersons[j].Id != int.Parse(contactpersonId))
                {
                    contactpersons.Add(selectedContactpersons[j]);
                }
            }

            Session["selectedContactpersons"] = contactpersons;

            return Json("", JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Klant Bewerking
        //Post method for redirecting to with seleceted id KlantBewerken page
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult EditCustomer(string customerId)
        {
            Session["CustomerId"] = customerId;

            //return RedirectToAction("RapportageBekijken", "Rapportages");
            return Json(new { result = "Redirect", url = Url.Action("KlantBewerken", "Overzichten") });
        }

        //Get method to KlantBewerken page
        public ActionResult KlantBewerken()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            Customer customer = databaseHandler.GetCustomer(int.Parse((Session["CustomerId"] as string)));

            List<Contactperson> contactpersons = databaseHandler.GetContactpersonsFromCustomer(customer);

            List<Contactperson> contactpersons2 = databaseHandler.GetContactpersonsFromCustomer(customer);

            //Session["TaskId"] = null;

            Session["contactpersonList"] = null;

            Session["previousContactpersonList"] = contactpersons2;
            Session["contactpersonList"] = contactpersons;


            return View(customer);
        }

        //Post method to KlantBewerken page
        [ValidateInput(true)]
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult KlantBewerken(Customer customer)
        {
            if (customer.Name == null || customer.Name == "")
            {
                ModelState.AddModelError("Naam", "Het veld mag niet leeg zijn!");
            }
            if (customer.Addres == null || customer.Addres == "")
            {
                ModelState.AddModelError("Adres", "Het veld mag niet leeg zijn!");
            }
            if (customer.Zipcode == null || customer.Zipcode == "")
            {
                ModelState.AddModelError("Postcode", "Het veld mag niet leeg zijn!");
            }
            if (customer.Residence == null || customer.Residence == "")
            {
                ModelState.AddModelError("Woonplaats", "Het veld mag niet leeg zijn!");
            }

            if (customer.Name != null && customer.Name != "" && customer.Addres != null && customer.Addres != "" && customer.Zipcode != null && customer.Zipcode != "" && customer.Residence != null && customer.Residence != "")
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                Customer aquiredCustomer = databaseHandler.GetCustomer(int.Parse((Session["CustomerId"] as string)));

                databaseHandler.EditCustomer(customer, aquiredCustomer.Id);

                if (Session["contactpersonList"] != null)
                {
                    List<Contactperson> selectedContactpersons = (Session["contactpersonList"] as List<Contactperson>);
                    List<Contactperson> removableContactpersons = new List<Contactperson> { };
                    List<Contactperson> addableContactpersons = new List<Contactperson> { };

                    if (Session["previousContactpersonList"] != null)
                    {
                        List<Contactperson> previousContactpersons = (Session["previousContactpersonList"] as List<Contactperson>);

                        for (int i = 0; i < previousContactpersons.Count; i++)
                        {
                            if (!selectedContactpersons.Contains(previousContactpersons[i]))
                            {
                                removableContactpersons.Add(previousContactpersons[i]);
                            }
                        }

                        for (int i = 0; i < selectedContactpersons.Count; i++)
                        {
                            if (!previousContactpersons.Contains(selectedContactpersons[i]))
                            {
                                addableContactpersons.Add(selectedContactpersons[i]);
                            }
                        }

                        if (removableContactpersons.Count != 0)
                        {
                            databaseHandler.RemoveContactpersonsFromCustomer(removableContactpersons, aquiredCustomer);
                        }
                        if (addableContactpersons.Count != 0)
                        {
                            databaseHandler.AddContactpersonsToCustomerWithId(addableContactpersons, aquiredCustomer.Id);
                        }
                    }
                    else
                    {
                        databaseHandler.AddContactpersonsToCustomerWithId(selectedContactpersons, aquiredCustomer.Id);
                    }
                }


                Session["contactpersonList"] = null;
                Session["previousContactpersonList"] = null;

                Session["CustomerId"] = null;

                return RedirectToAction("OverzichtKlanten", "Overzichten");
            }

            return View(customer);
        }

        //Post method for redirecting to with selected id PartnerBewerken page
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult EditPartner(string partnerId)
        {
            Session["PartnerId"] = partnerId;

            //return RedirectToAction("RapportageBekijken", "Rapportages");
            return Json(new { result = "Redirect", url = Url.Action("PartnerBewerken", "Overzichten") });
        }

        //Get method to PartnerBewerken page
        public ActionResult PartnerBewerken()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            Customer customer = databaseHandler.GetPartner(int.Parse((Session["PartnerId"] as string)));

            List<Contactperson> contactpersons = databaseHandler.GetContactpersonsFromCustomer(customer);

            List<Contactperson> contactpersons2 = databaseHandler.GetContactpersonsFromCustomer(customer);

            //Session["TaskId"] = null;

            Session["contactpersonList"] = null;

            Session["previousContactpersonList"] = contactpersons2;
            Session["contactpersonList"] = contactpersons;


            return View(customer);
        }

        //Post method to PartnerBewerken page
        [ValidateInput(true)]
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult PartnerBewerken(Customer customer)
        {
            if (customer.Name == null || customer.Name == "")
            {
                ModelState.AddModelError("Naam", "Het veld mag niet leeg zijn!");
            }
            if (customer.Addres == null || customer.Addres == "")
            {
                ModelState.AddModelError("Adres", "Het veld mag niet leeg zijn!");
            }
            if (customer.Zipcode == null || customer.Zipcode == "")
            {
                ModelState.AddModelError("Postcode", "Het veld mag niet leeg zijn!");
            }
            if (customer.Residence == null || customer.Residence == "")
            {
                ModelState.AddModelError("Woonplaats", "Het veld mag niet leeg zijn!");
            }

            if (customer.Name != null && customer.Name != "" && customer.Addres != null && customer.Addres != "" && customer.Zipcode != null && customer.Zipcode != "" && customer.Residence != null && customer.Residence != "")
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                Customer aquiredCustomer = databaseHandler.GetPartner(int.Parse((Session["PartnerId"] as string)));

                databaseHandler.EditPartner(customer, aquiredCustomer.Id);

                if (Session["contactpersonList"] != null)
                {
                    List<Contactperson> selectedContactpersons = (Session["contactpersonList"] as List<Contactperson>);
                    List<Contactperson> removableContactpersons = new List<Contactperson> { };
                    List<Contactperson> addableContactpersons = new List<Contactperson> { };

                    if (Session["previousContactpersonList"] != null)
                    {
                        List<Contactperson> previousContactpersons = (Session["previousContactpersonList"] as List<Contactperson>);

                        for (int i = 0; i < previousContactpersons.Count; i++)
                        {
                            if (!selectedContactpersons.Contains(previousContactpersons[i]))
                            {
                                removableContactpersons.Add(previousContactpersons[i]);
                            }
                        }

                        for (int i = 0; i < selectedContactpersons.Count; i++)
                        {
                            if (!previousContactpersons.Contains(selectedContactpersons[i]))
                            {
                                addableContactpersons.Add(selectedContactpersons[i]);
                            }
                        }

                        if (removableContactpersons.Count != 0)
                        {
                            databaseHandler.RemoveContactpersonsFromCustomer(removableContactpersons, aquiredCustomer);
                        }
                        if (addableContactpersons.Count != 0)
                        {
                            databaseHandler.AddContactpersonsToCustomerWithId(addableContactpersons, aquiredCustomer.Id);
                        }
                    }
                    else
                    {
                        databaseHandler.AddContactpersonsToCustomerWithId(selectedContactpersons, aquiredCustomer.Id);
                    }
                }


                Session["contactpersonList"] = null;
                Session["previousContactpersonList"] = null;

                Session["PartnerId"] = null;

                return RedirectToAction("OverzichtPartners", "Overzichten");
            }

            return View(customer);
        }

        //Post for getting the list of contactpersons
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetContactpersonsList()
        {
            List<Contactperson> contactpersonsList = (List<Contactperson>)Session["contactpersonList"];

            string htmlContent = "";

            if (Session["contactpersonList"] != null)
            {
                for (int i = 0; i < contactpersonsList.Count; i++)
                {
                    htmlContent += "<div class=\"" + "contactperson-segment" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentContactpersonClick(" + contactpersonsList[i].Id.ToString() + ")" + "\">";
                    htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                    htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + contactpersonsList[i].Name + "</label>";
                    htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveContactPerson(" + contactpersonsList[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + contactpersonsList[i].Id.ToString() + "\"></span>";
                    htmlContent += "</div>";
                }
            }

            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post for adding a contactperson to the list of contactpersons
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddContactPerson(string name, string email, string telephonenumber, string accountmanager)
        {
            if (name != null && name != "" && email != null && email != "" && telephonenumber != null && telephonenumber != "" && accountmanager != null && accountmanager != "")
            {
                List<Contactperson> selectedContactpersons = new List<Contactperson> { };
                Contactperson contactperson = new Contactperson();
                contactperson.Name = name;
                contactperson.Email = email;
                contactperson.Telephonenumber = telephonenumber;
                contactperson.Accountmanager = Convert.ToBoolean(int.Parse(accountmanager));


                if (Session["contactpersonList"] != null)
                {
                    selectedContactpersons = (List<Contactperson>)Session["contactpersonList"];
                    selectedContactpersons.Add(contactperson);
                    Session["contactpersonList"] = selectedContactpersons;
                }
                else
                {
                    selectedContactpersons = new List<Contactperson> { contactperson };
                    Session["contactpersonList"] = selectedContactpersons;
                }

                contactperson.Id = selectedContactpersons.Count();


                string htmlContent = "";

                for (int i = 0; i < selectedContactpersons.Count; i++)
                {
                    htmlContent += "<div class=\"" + "contactperson-segment" + "\" id=\"" + selectedContactpersons[i].Id.ToString() + "\">";
                    htmlContent += "<label>" + (i + 1).ToString() + "</label>";
                    htmlContent += "<label>" + selectedContactpersons[i].Name + "</label>";

                    if (selectedContactpersons[i].Accountmanager == true)
                    {
                        htmlContent += "<label>" + "Accountmanger" + "</label>";
                    }

                    htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveContactPerson(" + selectedContactpersons[i].Id.ToString() + ")" + "\"></span>";
                    htmlContent += "</div>";
                }

                return Json(htmlContent, JsonRequestBehavior.AllowGet);
            }
            else
            {
                ModelState.AddModelError("errormessage", "Één of meerdere velden ontbreken!");

                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        //Post for removing a contactperson from the list of contactpersons
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult RemoveContactPerson(string contactpersonId)
        {
            List<Contactperson> selectedContactpersons = (List<Contactperson>)Session["contactpersonList"];

            List<Contactperson> contactpersons = new List<Contactperson> { };

            for (int j = 0; j < selectedContactpersons.Count; j++)
            {
                if (selectedContactpersons[j].Id != int.Parse(contactpersonId))
                {
                    if (contactpersons.Count == 0)
                    {
                        selectedContactpersons[j].Id = 1;
                    }
                    else
                    {
                        selectedContactpersons[j].Id = contactpersons.Count + 1;
                    }
                    contactpersons.Add(selectedContactpersons[j]);
                }
            }

            Session["contactpersonList"] = contactpersons;

            string htmlContent = "";

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "contactperson-segment" + "\" id=\"" + contactpersons[i].Id.ToString() + "\">";
                htmlContent += "<label>" + (i + 1).ToString() + "</label>";
                htmlContent += "<label>" + contactpersons[i].Name + "</label>";

                if (contactpersons[i].Accountmanager == true)
                {
                    htmlContent += "<label>" + "Accountmanger" + "</label>";
                }

                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveContactPerson(" + contactpersons[i].Id.ToString() + ")" + "\"></span>";
                htmlContent += "</div>";
            }

            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}