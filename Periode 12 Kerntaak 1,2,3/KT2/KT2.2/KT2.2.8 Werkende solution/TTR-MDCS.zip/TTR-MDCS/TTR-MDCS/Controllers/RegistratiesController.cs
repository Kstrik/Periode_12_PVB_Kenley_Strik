﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TTR_MDCS.Classes;
using TTR_MDCS.Models;

namespace TTR_MDCS.Controllers
{
    [IsAuthorized(Roles = new string[1]{ "Admin" })]
    public class RegistratiesController : Controller
    {
        // GET: Registraties
        public ActionResult Index()
        {
            return View();
        }

        #region Taak Registratie
        //Get method to TaakRegistreren page
        public ActionResult TaakRegistreren()
        {
            Session["searchedCustomers"] = null;
            Session["selectedCustomers"] = null;
            Session["searchedContactpersons"] = null;
            Session["selectedContactpersons"] = null;
            return View();
        }

        //Post method to TaakRegistreren page
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult TaakRegistreren(Task task)
        {
            if (task.Description == null || task.Description == "")
            {
                ModelState.AddModelError("Omschrijving", "Het veld mag niet leeg zijn!");
            }
            if(task.Date == null)
            {
                ModelState.AddModelError("Datum", "Het veld mag niet leeg zijn!");
            }
            if(!ModelState.IsValidField("Date"))
            {
                ModelState.AddModelError("Datum", "Incorrect!");
            }
            
            if(task.Description != null && task.Description != "" && ModelState.IsValidField("Date"))
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                databaseHandler.AddTask(task);

                if (Session["customerName"] != null)
                {
                    Customer customer = new Customer();
                    customer.Name = (Session["customerName"] as string);
                    databaseHandler.AddCustomerStart(customer);
                    databaseHandler.AddCustomerToTask(customer, task);
                }
                if (Session["selectedCustomers"] != null)
                {
                    databaseHandler.AddCustomersToTask((Session["selectedCustomers"] as List<Customer>), task);
                }
                if (Session["selectedContactpersons"] != null)
                {
                    databaseHandler.AddContactpersonsToTask((Session["selectedContactpersons"] as List<Contactperson>), task);
                }

                Session["searchedCustomers"] = null;
                Session["selectedCustomers"] = null;
                Session["searchedContactpersons"] = null;
                Session["selectedContactpersons"] = null;

                return RedirectToAction("OverzichtTaken", "Overzichten");
            }
            return View(task);
        }

        //Post method for setting the template of the customername
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult SetTemplateCustomerName(string customerName)
        {
            Session["customerName"] = customerName;

            return Json("", JsonRequestBehavior.AllowGet);
        }

        //Get method for getting the customers that can be searched
        [AcceptVerbs(HttpVerbs.Get)]
        public JsonResult GetSearchableCustomers()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> aquiredCustomers = new List<Customer> { };
            aquiredCustomers = databaseHandler.GetCustomersAndPartnersTCLOAN();

            List<Customer> customers = new List<Customer> { };
            if(Session["selectedCustomers"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedCustomers"] as List<Customer>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredCustomers.Count; j++)
                {
                    if (!tempIds.Contains(aquiredCustomers[j].Id))
                    {
                        customers.Add(aquiredCustomers[j]);
                    }
                }
            }
            else
            {
                customers = aquiredCustomers;
            }

            string htmlContent = "";

            Session["searchedCustomers"] = customers;

            for (int i = 0; i < customers.Count; i++)
            {
                string htmlString = "";
                if (customers[i].Partner == true)
                {
                    htmlString = "Partner";
                }
                else
                {
                    htmlString = "Klant";
                }

                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + customers[i].Id.ToString() + "\" onclick=\"" + "OnSegmentCustomerClick(" + customers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + customers[i].Name + "</label>";
                htmlContent += "<label class=\"" + "pull-right" + "\" style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + htmlString + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting the customers with specific names
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetCustomersByName(string name)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> aquiredCustomers = new List<Customer> { };
            aquiredCustomers = databaseHandler.GetCustomersAndPartnersByName(name);

            List<Customer> customers = new List<Customer> { };
            if (Session["selectedCustomers"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedCustomers"] as List<Customer>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredCustomers.Count; j++)
                {
                    if (!tempIds.Contains(aquiredCustomers[j].Id))
                    {
                        customers.Add(aquiredCustomers[j]);
                    }
                }
            }
            else
            {
                customers = aquiredCustomers;
            }

            string htmlContent = "";

            Session["searchedCustomers"] = customers;

            for(int i = 0; i < customers.Count; i++)
            {
                string htmlString = "";
                if (customers[i].Partner == true)
                {
                    htmlString = "Partner";
                }
                else
                {
                    htmlString = "Klant";
                }

                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + customers[i].Id.ToString() + "\" onclick=\"" + "OnSegmentCustomerClick(" + customers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + customers[i].Name + "</label>";
                htmlContent += "<label class=\"" + "pull-right" + "\" style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + htmlString + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for adding the customer to the selected customers list
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddSelectedCustomerItem(string customerId)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> selectedCustomers = new List<Customer> { };
            Customer customer = databaseHandler.GetCustomerTCLOAN(int.Parse(customerId));

            if (Session["selectedCustomers"] != null)
            {
                selectedCustomers = (List<Customer>)Session["selectedCustomers"];
                selectedCustomers.Add(customer);
                Session["selectedCustomers"] = selectedCustomers;
            }
            else
            {
                selectedCustomers = new List<Customer> { customer };
                Session["selectedCustomers"] = selectedCustomers;
            }

            string htmlContent = "";

            for (int i = 0; i < selectedCustomers.Count; i++)
            {
                //string htmlString = "";
                //if (selectedCustomers[i].Partner == true)
                //{
                //    htmlString = "Partner";
                //}
                //else
                //{
                //    htmlString = "Klant";
                //}

                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentCustomerClick(" + selectedCustomers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedCustomers[i].Name + "</label>";
                //htmlTableContent += "<label class=\"" + "pull-right" + "\" style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + htmlString + "</label>";
                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedCustomerItem(" + selectedCustomers[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedCustomers[i].Id.ToString() + "\"></span>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting the customers from the selected customers list
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetSelectedCustomers()
        {
            List<Customer> selectedCustomers = (List<Customer>)Session["selectedCustomers"];

            string htmlContent = "";

            for (int i = 0; i < selectedCustomers.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentCustomerClick(" + selectedCustomers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedCustomers[i].Name + "</label>";
                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedCustomerItem(" + selectedCustomers[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedCustomers[i].Id.ToString() + "\"></span>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for removing the customer from the selected customers list
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult RemoveSelectedCustomerItem(string customerId)
        {
            List<Customer> selectedCustomers = (List<Customer>)Session["selectedCustomers"];

            List<Customer> customers = new List<Customer> { };

            for(int j = 0; j < selectedCustomers.Count; j++)
            {
                if(selectedCustomers[j].Id != int.Parse(customerId))
                {
                    customers.Add(selectedCustomers[j]);
                }
            }

            Session["selectedCustomers"] = customers;

            return Json("", JsonRequestBehavior.AllowGet);
        }

        //Get method for getting the contactpersons that can be searched
        [AcceptVerbs(HttpVerbs.Get)]
        public JsonResult GetSearchableContactpersons()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> aquiredContactpersons = new List<Contactperson> { };
            aquiredContactpersons = databaseHandler.GetContactpersonsTCLOAN();

            List<Contactperson> contactpersons = new List<Contactperson> { };
            if (Session["selectedContactpersons"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedContactpersons"] as List<Contactperson>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredContactpersons.Count; j++)
                {
                    if (!tempIds.Contains(aquiredContactpersons[j].Id))
                    {
                        contactpersons.Add(aquiredContactpersons[j]);
                    }
                }
            }
            else
            {
                contactpersons = aquiredContactpersons;
            }

            string htmlContent = "";

            Session["searchedContactpersons"] = contactpersons;

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + contactpersons[i].Id.ToString() + "\" onclick=\"" + "OnSegmentContactpersonClick(" + contactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + contactpersons[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting the contactpersons with specific names
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetContactpersonsByName(string name)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> aquiredContactpersons = new List<Contactperson> { };
            aquiredContactpersons = databaseHandler.GetContactpersonsByName(name);

            List<Contactperson> contactpersons = new List<Contactperson> { };
            if (Session["selectedContactpersons"] != null)
            {
                IEnumerable<int> tempIds = (Session["selectedContactpersons"] as List<Contactperson>).Select(x => x.Id).Distinct();

                for (int j = 0; j < aquiredContactpersons.Count; j++)
                {
                    if (!tempIds.Contains(aquiredContactpersons[j].Id))
                    {
                        contactpersons.Add(aquiredContactpersons[j]);
                    }
                }
            }
            else
            {
                contactpersons = aquiredContactpersons;
            }

            string htmlContent = "";

            Session["searchedCustomers"] = contactpersons;

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + contactpersons[i].Id.ToString() + "\" onclick=\"" + "OnSegmentContactpersonClick(" + contactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + contactpersons[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for adding the contactperson to the selected contactpersons list
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddSelectedContactpersonItem(string contactpersonId)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Contactperson> selectedContactpersons = new List<Contactperson> { };
            Contactperson contactperson = databaseHandler.GetContactpersonTCLOAN(int.Parse(contactpersonId));

            if (Session["selectedContactpersons"] != null)
            {
                selectedContactpersons = (List<Contactperson>)Session["selectedContactpersons"];
                selectedContactpersons.Add(contactperson);
                Session["selectedContactpersons"] = selectedContactpersons;
            }
            else
            {
                selectedContactpersons = new List<Contactperson> { contactperson };
                Session["selectedContactpersons"] = selectedContactpersons;
            }

            string htmlContent = "";

            for (int i = 0; i < selectedContactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentContactpersonClick(" + selectedContactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedContactpersons[i].Name + "</label>";
                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedContactpersonItem(" + selectedContactpersons[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedContactpersons[i].Id.ToString() + "\"></span>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for getting the contactperons from the selected contactpersons list
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetSelectedContactpersons()
        {
            List<Contactperson> selectedContactpersons = (List<Contactperson>)Session["selectedContactpersons"];

            string htmlContent = "";

            for (int i = 0; i < selectedContactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-contactpersons" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" onclick=\"" + "OnSegmentContactpersonClick(" + selectedContactpersons[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + selectedContactpersons[i].Name + "</label>";
                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveSelectedContactpersonItem(" + selectedContactpersons[i].Id.ToString() + ")" + "\" style=\"" + "height: 20px;" + "\"  id=\"" + selectedContactpersons[i].Id.ToString() + "\"></span>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for removing the contactperson from the selected contactpersons list
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult RemoveSelectedContactpersonItem(string contactpersonId)
        {
            List<Contactperson> selectedContactpersons = (List<Contactperson>)Session["selectedContactpersons"];

            List<Contactperson> contactpersons = new List<Contactperson> { };

            for (int j = 0; j < selectedContactpersons.Count; j++)
            {
                if (selectedContactpersons[j].Id != int.Parse(contactpersonId))
                {
                    contactpersons.Add(selectedContactpersons[j]);
                }
            }

            Session["selectedContactpersons"] = contactpersons;

            return Json("", JsonRequestBehavior.AllowGet);
        }
        #endregion

        //Get method to KlantRegistreren page
        public ActionResult KlantRegistreren()
        {
            Session["contactpersonList"] = null;

            return View();
        }

        //Post method to KlantRegistreren page
        [ValidateInput(true)]
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult KlantRegistreren(Customer customer)
        {
            if (customer.Name == null || customer.Name == "")
            {
                ModelState.AddModelError("Naam", "Het veld mag niet leeg zijn!");
            }
            if (customer.Addres == null || customer.Addres == "")
            {
                ModelState.AddModelError("Adres", "Het veld mag niet leeg zijn!");
            }
            if (customer.Zipcode == null || customer.Zipcode == "")
            {
                ModelState.AddModelError("Postcode", "Het veld mag niet leeg zijn!");
            }
            if (customer.Residence == null || customer.Residence == "")
            {
                ModelState.AddModelError("Woonplaats", "Het veld mag niet leeg zijn!");
            }

            if (customer.Name != null && customer.Name != "" && customer.Addres != null && customer.Addres != "" && customer.Zipcode != null && customer.Zipcode != "" && customer.Residence != null && customer.Residence != "")
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                databaseHandler.AddCustomer(customer);

                if (Session["contactpersonList"] != null)
                {
                    databaseHandler.AddContactpersonsToCustomer((Session["contactpersonList"] as List<Contactperson>), customer);
                }

                Session["contactpersonList"] = null;

                return RedirectToAction("OverzichtKlanten", "Overzichten");
            }


            return View(customer);
        }

        //Get method to PartnerRegistreren page
        public ActionResult PartnerRegistreren()
        {
            Session["contactpersonList"] = null;
            Session["selectedCustomer"] = null;
            Session["searchedCustomers"] = null;

            return View();
        }

        //Post method to PartnerRegistreren page
        [ValidateInput(true)]
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult PartnerRegistreren(Customer customer)
        {
            if (Session["selectedCustomer"] != null)
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                databaseHandler.ChangeCustomerToPartner((Session["selectedCustomer"] as Customer));

                return RedirectToAction("OverzichtPartners", "Overzichten");
            }
            else
            {
                if (customer.Name == null || customer.Name == "")
                {
                    ModelState.AddModelError("Naam", "Het veld mag niet leeg zijn!");
                }
                if (customer.Addres == null || customer.Addres == "")
                {
                    ModelState.AddModelError("Adres", "Het veld mag niet leeg zijn!");
                }
                if (customer.Zipcode == null || customer.Zipcode == "")
                {
                    ModelState.AddModelError("Postcode", "Het veld mag niet leeg zijn!");
                }
                if (customer.Residence == null || customer.Residence == "")
                {
                    ModelState.AddModelError("Woonplaats", "Het veld mag niet leeg zijn!");
                }

                if (customer.Name != null && customer.Name != "" && customer.Addres != null && customer.Addres != "" && customer.Zipcode != null && customer.Zipcode != "" && customer.Residence != null && customer.Residence != "")
                {
                    DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                    databaseHandler.AddPartner(customer);

                    if (Session["contactpersonList"] != null)
                    {
                        databaseHandler.AddContactpersonsToCustomer((Session["contactpersonList"] as List<Contactperson>), customer);
                    }

                    Session["contactpersonList"] = null;

                    return RedirectToAction("OverzichtPartners", "Overzichten");
                }

                return View(customer);
            }
        }

        //Post mehtod for adding a selected contactperson to the list of contactpersons
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddContactPerson(string name, string email, string telephonenumber, string accountmanager)
        {
            if (name != null && name != "" && email != null && email != "" && telephonenumber != null && telephonenumber != "" && accountmanager != null && accountmanager != "")
            {
                List<Contactperson> selectedContactpersons = new List<Contactperson> { };
                Contactperson contactperson = new Contactperson();
                contactperson.Name = name;
                contactperson.Email = email;
                contactperson.Telephonenumber = telephonenumber;
                contactperson.Accountmanager = Convert.ToBoolean(int.Parse(accountmanager));


                if (Session["contactpersonList"] != null)
                {
                    selectedContactpersons = (List<Contactperson>)Session["contactpersonList"];
                    selectedContactpersons.Add(contactperson);
                    Session["contactpersonList"] = selectedContactpersons;
                }
                else
                {
                    selectedContactpersons = new List<Contactperson> { contactperson };
                    Session["contactpersonList"] = selectedContactpersons;
                }

                contactperson.Id = selectedContactpersons.Count();


                string htmlContent = "";

                for (int i = 0; i < selectedContactpersons.Count; i++)
                {
                    htmlContent += "<div class=\"" + "contactperson-segment" + "\" id=\"" + selectedContactpersons[i].Id.ToString() + "\">";
                    htmlContent += "<label>" + (i + 1).ToString() + "</label>";
                    htmlContent += "<label>" + selectedContactpersons[i].Name + "</label>";

                    if (selectedContactpersons[i].Accountmanager == true)
                    {
                        htmlContent += "<label>" + "Accountmanger" + "</label>";
                    }

                    htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveContactPerson(" + selectedContactpersons[i].Id.ToString() + ")" + "\"></span>";
                    htmlContent += "</div>";
                }

                return Json(htmlContent, JsonRequestBehavior.AllowGet);
            }
            else
            {
                ModelState.AddModelError("errormessage", "Één of meerdere velden ontbreken!");

                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        //Post mehtod for removing a selected contactperson from the list of contactpersons
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult RemoveContactPerson(string contactpersonId)
        {
            List<Contactperson> selectedContactpersons = (List<Contactperson>)Session["contactpersonList"];

            List<Contactperson> contactpersons = new List<Contactperson> { };

            for (int j = 0; j < selectedContactpersons.Count; j++)
            {
                if (selectedContactpersons[j].Id != int.Parse(contactpersonId))
                {
                    if (contactpersons.Count == 0)
                    {
                        selectedContactpersons[j].Id = 1;
                    }
                    else
                    {
                        selectedContactpersons[j].Id = contactpersons.Count + 1;
                    }
                    contactpersons.Add(selectedContactpersons[j]);
                }
            }

            Session["contactpersonList"] = contactpersons;

            string htmlContent = "";

            for (int i = 0; i < contactpersons.Count; i++)
            {
                htmlContent += "<div class=\"" + "contactperson-segment" + "\" id=\"" + contactpersons[i].Id.ToString() + "\">";
                htmlContent += "<label>" + (i + 1).ToString() + "</label>";
                htmlContent += "<label>" + contactpersons[i].Name + "</label>";

                if (contactpersons[i].Accountmanager == true)
                {
                    htmlContent += "<label>" + "Accountmanger" + "</label>";
                }

                htmlContent += "<span class=\"" + "fa fa-minus pull-right" + "\" onclick=\"" + "RemoveContactPerson(" + contactpersons[i].Id.ToString() + ")" + "\"></span>";
                htmlContent += "</div>";
            }

            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post mehtod for adding a selected customer to the list of selected customers
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddCustomerToSelection(string customerId)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            Customer customer = databaseHandler.GetCustomer(int.Parse(customerId));

            Session["selectedCustomer"] = customer;

            string htmlContent = customer.Name;

            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Get mehtod for getting a the list of customers
        [AcceptVerbs(HttpVerbs.Get)]
        public JsonResult GetCustomers()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> customers = new List<Customer> { };
            customers = databaseHandler.GetCustomers();

            string htmlContent = "";

            Session["searchedCustomers"] = customers;

            for (int i = 0; i < customers.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + customers[i].Id.ToString() + "\" onclick=\"" + "OnSegmentCustomerClick(" + customers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + customers[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }

        //Post mehtod for getting a customer with a spacific name
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetOnlyCustomersByName(string name)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Customer> customers = new List<Customer> { };
            customers = databaseHandler.GetCustomersByName(name);

            string htmlContent = "";

            Session["searchedCustomers"] = customers;

            for (int i = 0; i < customers.Count; i++)
            {
                htmlContent += "<div class=\"" + "segment-dropdownmenu segment-dropdownmenu-button-customers" + "\" style=\"" + "padding: 5px; height: 40px;" + "\" id=\"" + customers[i].Id.ToString() + "\" onclick=\"" + "OnSegmentCustomerClick(" + customers[i].Id.ToString() + ")" + "\">";
                htmlContent += "<label style=\"" + "font-size: 14px;" + "\">" + (i + 1).ToString() + "</label>";
                htmlContent += "<label style=\"" + "margin-left: 10px; font-size: 14px;" + "\">" + customers[i].Name + "</label>";
                htmlContent += "</div>";
            }


            return Json(htmlContent, JsonRequestBehavior.AllowGet);
        }
    }
}