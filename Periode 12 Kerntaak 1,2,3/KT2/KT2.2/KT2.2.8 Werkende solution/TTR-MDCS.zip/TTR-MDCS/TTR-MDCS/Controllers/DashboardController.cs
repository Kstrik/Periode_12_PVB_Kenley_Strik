﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TTR_MDCS.Classes;

namespace TTR_MDCS.Controllers
{
    [IsAuthorized(Roles = new string[1] { "Admin" })]
    public class DashboardController : Controller
    {
        //Get method to dashboard page
        public ActionResult Dashboard()
        {
            return View();
        }
    }
}