﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TTR_MDCS.Classes;
using TTR_MDCS.Models;

namespace TTR_MDCS.Controllers
{
    //[Authorize(Roles = "Admin")]
    public class LoginController : Controller
    {
        //Get method to login page
        public ActionResult Login()
        {
            User user = new User();
            UserViewModel userViewModel = new UserViewModel();
            userViewModel.User = user;

            if (Request.Cookies["TTR.MDCS-Password"] != null)
            {
                string[] properties = Request.Cookies["TTR.MDCS-Password"].Value.Split(',');
                userViewModel.User.Username = properties[0];
                userViewModel.User.Password = properties[1];
                userViewModel.User.Email = properties[2];
                userViewModel.User.Role = properties[3];
                userViewModel.RememberPassword = true;
            }

            return View(userViewModel);
        }

        //Post method for login page
        [ValidateInput(true)]
        [ValidateAntiForgeryToken]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Login(UserViewModel userViewModel)
        {
            if (ModelState.IsValid && userViewModel.User.Password != null && userViewModel.User.Username != null)
            {
                DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();

                UtilityHelper utilityHelper = new UtilityHelper();
                string hashedPassword = utilityHelper.GetHashedValue(userViewModel.User.Password);

                User acquiredUser = new User();

                acquiredUser = databaseHandler.GetUser(userViewModel.User.Username, hashedPassword);

                if (acquiredUser.Password != null)
                {
                    if (userViewModel.RememberPassword == true && Request.Cookies["TTR.MDCS-Password"] == null)
                    {
                        HttpCookie passwordCookie = new HttpCookie("TTR.MDCS-Password");
                        passwordCookie.Value = acquiredUser.Username + "," + userViewModel.User.Password + "," + acquiredUser.Email + "," + acquiredUser.Role;
                        passwordCookie.Expires = DateTime.MaxValue;
                        Response.Cookies.Add(passwordCookie);
                    }
                    else if (userViewModel.RememberPassword == true && Request.Cookies["TTR.MDCS-Password"] != null)
                    {
                        HttpCookie passwordCookie = new HttpCookie("TTR.MDCS-Password");
                        passwordCookie.Value = acquiredUser.Username + "," + userViewModel.User.Password + "," + acquiredUser.Email + "," + acquiredUser.Role;
                        passwordCookie.Expires = DateTime.MaxValue;
                        Response.Cookies["TTR.MDCS-Password"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies.Add(passwordCookie);
                    }
                    else if (userViewModel.RememberPassword == false && Request.Cookies["TTR.MDCS-Password"] != null)
                    {
                        Response.Cookies["TTR.MDCS-Password"].Expires = DateTime.Now.AddDays(-1);
                    }

                    Session["key"] = acquiredUser;
                    return RedirectToAction("Dashboard", "Dashboard");
                }
                else
                {
                    ModelState.AddModelError("Username/Password", "Username or Password is incorrect!");
                }
            }
            else
            {
                if(userViewModel.User.Username == null && userViewModel.User.Password == null)
                {
                    ModelState.AddModelError("User.Username", "Invoerveld is leeg!");
                    ModelState.AddModelError("User.Password", "Invoerveld is leeg!");
                }
                else if(userViewModel.User.Username == null)
                {
                    ModelState.AddModelError("User.Username", "Invoerveld is leeg!");
                }
                else
                {
                    ModelState.AddModelError("User.Password", "Invoerveld is leeg!");
                }
            }

            return View(userViewModel);
        }

        //Get method to logout page
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login", "Login");
        }
    }
}