﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TTR_MDCS.Classes;
using TTR_MDCS.Models;

namespace TTR_MDCS.Controllers
{
    [IsAuthorized(Roles = new string[1] { "Admin" })]
    public class RapportagesController : Controller
    {
        // GET: Rapportages
        public ActionResult Index()
        {
            return View();
        }

        //Get method to RapportageOpzetten page
        public ActionResult RapportageOpzetten()
        {
            return View();
        }

        //Post method to RapportageOpzetten page
        [ValidateInput(true)]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult RapportageOpzetten(List<Task> tasks)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Task> aquiredTasks = (List<Task>)Session["ReportTasks"];

            if (databaseHandler.CheckReportExcistence((Session["Date"] as string).Split(',')[0], (Session["Date"] as string).Split(',')[1]) == false)
            {
                Report report = new Report(new DateTime(int.Parse((Session["Date"] as string).Split(',')[0]), int.Parse((Session["Date"] as string).Split(',')[1]), 1));
                Session["Date"] = null;
                databaseHandler.AddReport(report);
                databaseHandler.AddTasksToReport(aquiredTasks, report);
                Session["ReportTasks"] = null;
                return RedirectToAction("RapportageInzien", "Rapportages");
            }
            else
            {
                ModelState.AddModelError("Report", "Report already excists!");
            }

            return View(aquiredTasks);
        }

        //Get method to RapportageInzien page
        public ActionResult RapportageInzien()
        {
            //DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            //Report report = databaseHandler.GetReport(2);
            //List<Task> tasks = databaseHandler.GetTasksFromReport(report);

            return View();
        }

        //Post method to for getting a report with specific values
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetReport(string year, string month)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            Report report = new Report();
            report = databaseHandler.GetReportFromYearAndMonth(year, month);
            List<Task> tasks = new List<Task> { };

            string htmlTableContent = "";

            if (report != null)
            {
                tasks = databaseHandler.GetTasksFromReport(report);
                Session["ReportTasks"] = tasks;

                htmlTableContent += "<tr id=\"" + report.Id + "\">";
                htmlTableContent += "<td>" + 1 + "</td>";
                htmlTableContent += "<td>" + report.Date.Year + "</td>";
                htmlTableContent += "<td>" + report.Date.ToString("MMMMMMMMM") + "</td>";
                htmlTableContent += "<td><a class=\"" + "fa fa-search pull-right" + "\" onclick=\"" + "ShowReport(" + report.Id.ToString() + ")" + "\"></a></td>";
                htmlTableContent += "</td>";
            }

            return Json(htmlTableContent, JsonRequestBehavior.AllowGet);
        }

        //Post method to for getting all tasks linked to a report that fall withing a specific year and month
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetTasksFromYearAndMonth(string year, string month)
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            List<Task> tasks = databaseHandler.GetTasksFromYearAndMonth(year, month);

            Session["ReportTasks"] = tasks;
            Session["Date"] = year + "," + month.Split('-')[1];

            string htmlTableContent = "";

            for(int i = 0; i < tasks.Count(); i++)
            {
                htmlTableContent += "<tr id=\"" + tasks[i].Id + "\">";
                htmlTableContent += "<td>" + (i + 1) + "</td>";
                htmlTableContent += "<td>" + tasks[i].Description + "</td>";
                htmlTableContent += "<td>" + tasks[i].Date.ToString() + "</td>";
                if(!Request.Browser.IsMobileDevice)
                {
                    htmlTableContent += "<td>" + tasks[i].Visit.ToString() + "</td>";
                    htmlTableContent += "<td>" + tasks[i].Research.ToString() + "</td>";
                    htmlTableContent += "<td>" + tasks[i].Conference_call.ToString() + "</td>";
                }
                htmlTableContent += "<td>" + tasks[i].Status + "</td>";
                htmlTableContent += "</td>";
            }

            return Json(htmlTableContent, JsonRequestBehavior.AllowGet);
        }

        //Post method for redirecting to the RapportageBekijken page
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult ShowReport(string reportId)
        {
            Session["ReportId"] = reportId;

            //return RedirectToAction("RapportageBekijken", "Rapportages");
            return Json(new { result = "Redirect", url = Url.Action("RapportageBekijken", "Rapportages") });
        }

        //Get method to RapportageOpzetten page
        public ActionResult RapportageBekijken()
        {
            DatabaseHandler databaseHandler = DatabaseHandler.GetInstance();
            Report report = databaseHandler.GetReport(int.Parse((Session["ReportId"] as string)));
            List<Task> tasks = databaseHandler.GetTasksFromReport(report);

            Session["ReportId"] = null;

            return View(tasks);
        }
    }
}