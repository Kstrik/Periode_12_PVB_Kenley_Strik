﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace TTR_MDCS.Classes
{
    public class UtilityHelper
    {
        //Constuctor for intializing the class
        public UtilityHelper()
        {
                
        }

        //Hashes the value of a specific string in put (used for hasing the password)
        public string GetHashedValue(string input)
        {
            var crypt = new System.Security.Cryptography.SHA256Managed();
            var hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(input));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }
    }
}