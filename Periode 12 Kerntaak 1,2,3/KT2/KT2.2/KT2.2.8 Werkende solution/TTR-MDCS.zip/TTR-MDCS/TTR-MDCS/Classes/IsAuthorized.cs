﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TTR_MDCS.Models;

namespace TTR_MDCS.Classes
{
    //Checks for authenticatie by looking at the sidgned in user a giving acces to those with the right role
    public class IsAuthorized : ActionFilterAttribute
    {
        public string[] Roles { get; set; }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (System.Web.HttpContext.Current.Session["key"] == null)
            {
                filterContext.Result = new RedirectToRouteResult(
                         new System.Web.Routing.RouteValueDictionary {
                        {"controller", "Login"}, {"action", "Login"}
                        }
                    );
            }
            else if (!Roles.Contains((System.Web.HttpContext.Current.Session["key"] as User).Role))
            {
                filterContext.Result = new RedirectToRouteResult(
                     new System.Web.Routing.RouteValueDictionary {
                                    {"controller", "Dashboard"}, {"action", "Dashboard"}
                    }
                );
            }
            base.OnActionExecuting(filterContext);
        }
    }
}