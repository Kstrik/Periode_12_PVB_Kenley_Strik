﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using TTR_MDCS.Models;

namespace TTR_MDCS.Classes
{
    public class DatabaseHandler
    {
        private static DatabaseHandler Instance;
        private SqlConnection sqlConnectionTTRMDCS;
        private SqlConnection sqlConnectionTCLOAN;

        //Constructor for initializing the datbase handler
        private DatabaseHandler()
        {
            ConnectionStringSettings connectionStringTTRMDCS = ConfigurationManager.ConnectionStrings["TTR-MDCS"];
            ConnectionStringSettings connectionStringTCLOAN = ConfigurationManager.ConnectionStrings["TCLOAN"];
            if (connectionStringTTRMDCS == null || string.IsNullOrEmpty(connectionStringTTRMDCS.ConnectionString) || connectionStringTCLOAN == null || string.IsNullOrEmpty(connectionStringTCLOAN.ConnectionString))
            {
                throw new Exception("Fatal error: missing connecting string in web.config file");
            }

            sqlConnectionTTRMDCS = new SqlConnection(connectionStringTTRMDCS.ConnectionString);
            sqlConnectionTCLOAN = new SqlConnection(connectionStringTCLOAN.ConnectionString);
        }

        //Gets a list of users from the database
        public List<Task> GetTasks()
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Tasks", sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<Task> tasks = new List<Task>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Task task = new Task();
                    task.Id = int.Parse(sqlReader["Id"].ToString());
                    task.Description = sqlReader["Description"].ToString();
                    task.Date = Convert.ToDateTime(sqlReader["Date"].ToString());
                    task.Visit = int.Parse(sqlReader["Visit"].ToString());
                    task.Research = int.Parse(sqlReader["Research"].ToString());
                    task.Conference_call = int.Parse(sqlReader["Conference_call"].ToString());
                    task.Status = sqlReader["Status"].ToString();
                    tasks.Add(task);
                }
            }

            //Task task = (Task)command.ExecuteScalar();
            command.Connection.Close();
            return tasks;
        }

        //Get a list of users from the database with specific values of a filter
        public List<Task> GetTasksWithFilter(string year, string month, string status, string contactperson_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Tasks WHERE Date >= '" + year + "-" + month.Split('-')[1] + "-01'  AND Date <= '" + year + "-" + month.Split('-')[1] + "-" + DateTime.DaysInMonth(int.Parse(year), int.Parse(month.Split('-')[1])) + "' AND Status = @Status ORDER BY Date ASC", sqlConnectionTTRMDCS);
            command.Parameters.Add("@Status", status);
            command.Connection.Open();

            List<Task> tasks = new List<Task>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Task task = new Task();
                    task.Id = int.Parse(sqlReader["Id"].ToString());
                    task.Description = sqlReader["Description"].ToString();
                    task.Date = Convert.ToDateTime(sqlReader["Date"].ToString());
                    task.Visit = int.Parse(sqlReader["Visit"].ToString());
                    task.Research = int.Parse(sqlReader["Research"].ToString());
                    task.Conference_call = int.Parse(sqlReader["Conference_call"].ToString());
                    task.Status = sqlReader["Status"].ToString();
                    tasks.Add(task);
                }
            }

            command.Connection.Close();

            if (contactperson_Id != null)
            {
                List<int> ids = new List<int> { };

                SqlCommand contactpersonCommand = new SqlCommand("SELECT Task_Id FROM Tasks_Contactpersons WHERE Contactperson_Id = @Contactperson_Id", sqlConnectionTTRMDCS);
                contactpersonCommand.Parameters.Add("@Contactperson_Id", contactperson_Id);
                contactpersonCommand.Connection.Open();

                using (SqlDataReader sqlReader = contactpersonCommand.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        ids.Add(int.Parse(sqlReader["Task_ID"].ToString()));
                    }
                }

                contactpersonCommand.Connection.Close();

                List<Task> tempTasks = new List<Task>();

                for (int i = 0; i < tasks.Count; i++)
                {
                    if(ids.Contains(tasks[i].Id))
                    {
                        tempTasks.Add(tasks[i]);
                    }
                }

                tasks.Clear();
                tasks = tempTasks;
            }

            return tasks;
        }

        //Get a list of customers from the database with specific values of a filter
        public List<Customer> GetCustomersWithFilter(string name, string residence, string contactperson_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Naam LIKE @Name AND Woonplaats LIKE @Residence OR Woonplaats IS NULL AND Partner = 0", sqlConnectionTTRMDCS);
            command.Parameters.Add("@Name", name + "%");
            command.Parameters.Add("@Residence", residence + "%");
            command.Connection.Open();

            List<Customer> customers = new List<Customer>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Customer customer = new Customer();
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString();
                    customer.Addres = sqlReader["Adres"].ToString();
                    customer.Zipcode = sqlReader["Postcode"].ToString();
                    customer.Residence = sqlReader["Woonplaats"].ToString();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                    customers.Add(customer);
                }
            }

            command.Connection.Close();

            if (contactperson_Id != null)
            {
                List<int> ids = new List<int> { };

                SqlCommand contactpersonCommand = new SqlCommand("SELECT Klant_ID FROM Kant_ContPers WHERE ContPers_ID = @Contactperson_Id", sqlConnectionTTRMDCS);
                contactpersonCommand.Parameters.Add("@Contactperson_Id", contactperson_Id);
                contactpersonCommand.Connection.Open();

                using (SqlDataReader sqlReader = contactpersonCommand.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        ids.Add(int.Parse(sqlReader["Klant_ID"].ToString()));
                    }
                }

                contactpersonCommand.Connection.Close();

                List<int> customerIds = new List<int> { };

                for (int i = 0; i < customers.Count; i++)
                {
                    if (customers[i].Partner == false && ids.Contains(customers[i].Id))
                    {
                        customerIds.Add(customers[i].Id);
                    }
                }

                ids = customerIds;

                List<Customer> tempCustomers = new List<Customer>();

                for (int i = 0; i < customers.Count; i++)
                {
                    if (ids.Contains(customers[i].Id))
                    {
                        tempCustomers.Add(customers[i]);
                    }
                }

                customers.Clear();
                customers = tempCustomers;
            }

            return customers;
        }

        //Get a list of partners from the database with specific values of a filter
        public List<Customer> GetPartnersWithFilter(string name, string residence, string contactperson_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Naam LIKE @Name AND Woonplaats LIKE @Residence AND Partner = 1", sqlConnectionTTRMDCS);
            command.Parameters.Add("@Name", name + "%");
            command.Parameters.Add("@Residence", residence + "%");
            command.Connection.Open();

            List<Customer> customers = new List<Customer>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Customer customer = new Customer();
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString();
                    customer.Addres = sqlReader["Adres"].ToString();
                    customer.Zipcode = sqlReader["Postcode"].ToString();
                    customer.Residence = sqlReader["Woonplaats"].ToString();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                    customers.Add(customer);
                }
            }

            command.Connection.Close();

            if (contactperson_Id != null)
            {
                List<int> ids = new List<int> { };

                SqlCommand contactpersonCommand = new SqlCommand("SELECT Klant_ID FROM Kant_ContPers WHERE ContPers_ID = @Contactperson_Id", sqlConnectionTTRMDCS);
                contactpersonCommand.Parameters.Add("@Contactperson_Id", contactperson_Id);
                contactpersonCommand.Connection.Open();

                using (SqlDataReader sqlReader = contactpersonCommand.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        ids.Add(int.Parse(sqlReader["Klant_ID"].ToString()));
                    }
                }


                contactpersonCommand.Connection.Close();

                List<int> partnerIds = new List<int> { };

                for (int i = 0; i < customers.Count; i++)
                {
                    if (customers[i].Partner == true && ids.Contains(customers[i].Id))
                    {
                        partnerIds.Add(customers[i].Id);
                    }
                }

                ids = partnerIds;

                List<Customer> tempCustomers = new List<Customer>();

                for (int i = 0; i < customers.Count; i++)
                {
                    if (ids.Contains(customers[i].Id))
                    {
                        tempCustomers.Add(customers[i]);
                    }
                }

                customers.Clear();
                customers = tempCustomers;
            }

            return customers;
        }

        //Gets a list of tasks that fall in a specific year and month
        public List<Task> GetTasksFromYearAndMonth(string year, string month)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Tasks WHERE Date >= '" + year + "-" + month.Split('-')[1] + "-01'  AND Date <= '" + year + "-" + month.Split('-')[1] + "-" + DateTime.DaysInMonth(int.Parse(year), int.Parse(month.Split('-')[1])) + "' ORDER BY Date ASC", sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<Task> tasks = new List<Task>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Task task = new Task();
                    task.Id = int.Parse(sqlReader["Id"].ToString());
                    task.Description = sqlReader["Description"].ToString();
                    task.Date = Convert.ToDateTime(sqlReader["Date"].ToString());
                    task.Visit = int.Parse(sqlReader["Visit"].ToString());
                    task.Research = int.Parse(sqlReader["Research"].ToString());
                    task.Conference_call = int.Parse(sqlReader["Conference_call"].ToString());
                    task.Status = sqlReader["Status"].ToString();
                    tasks.Add(task);
                }
            }

            command.Connection.Close();
            return tasks;
        }

        //Gets a list of tasks that are linked to a report with a link table
        public List<Task> GetTasksFromReport(Report report)
        {
            //SqlCommand command = new SqlCommand("SELECT * FROM Reports_Tasks WHERE Report_Id = @ReportId", sqlConnectionTTRMDCS);
            //command.Parameters.Add(new SqlParameter("@ReportId", report.Id));
            SqlCommand command = new SqlCommand("SELECT * FROM Reports_Tasks WHERE Report_Id = " + report.Id.ToString(), sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<int> task_Ids = new List<int>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    task_Ids.Add(int.Parse(sqlReader["Task_Id"].ToString()));
                }
            }

            command.Connection.Close();

            string idsQuery = "";

            //for (int i = 0; i < task_Ids.Count; i++)
            //{
            //    idsQuery += "Id = '" + task_Ids[i] + "' ";
            //    if (i != task_Ids.Count - 1)
            //    {
            //        idsQuery += "OR ";
            //    }
            //}

            //SqlCommand tasksCommand = new SqlCommand("SELECT * FROM Tasks WHERE " + idsQuery + " ORDER BY Date ASC", sqlConnectionTTRMDCS);
            idsQuery += "Id in (";
            for (int i = 0; i < task_Ids.Count; i++)
            {
                idsQuery += "'" + task_Ids[i] + "'";
                if (i != task_Ids.Count - 1)
                {
                    idsQuery += ",";
                }
            }
            idsQuery += ")";

            SqlCommand tasksCommand = new SqlCommand("SELECT * FROM Tasks WHERE " + idsQuery + " ORDER BY Date ASC", sqlConnectionTTRMDCS);
            tasksCommand.Connection.Open();

            List<Task> tasks = new List<Task>();

            using (SqlDataReader sqlReader = tasksCommand.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Task task = new Task();
                    task.Id = int.Parse(sqlReader["Id"].ToString());
                    task.Description = sqlReader["Description"].ToString();
                    task.Date = Convert.ToDateTime(sqlReader["Date"].ToString());
                    task.Visit = int.Parse(sqlReader["Visit"].ToString());
                    task.Research = int.Parse(sqlReader["Research"].ToString());
                    task.Conference_call = int.Parse(sqlReader["Conference_call"].ToString());
                    task.Status = sqlReader["Status"].ToString();
                    tasks.Add(task);
                }
            }

            tasksCommand.Connection.Close();
            return tasks;
        }

        //Gets a task with a specific id
        public Task GetTask(int task_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Tasks WHERE Id = @TaskId", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@TaskId", task_Id));
            command.Connection.Open();

            Task task = new Task();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    task.Id = int.Parse(sqlReader["Id"].ToString());
                    task.Description = sqlReader["Description"].ToString().Trim();
                    task.Date = Convert.ToDateTime(sqlReader["Date"].ToString());
                    task.Visit = int.Parse(sqlReader["Visit"].ToString());
                    task.Research = int.Parse(sqlReader["Research"].ToString());
                    task.Conference_call = int.Parse(sqlReader["Conference_call"].ToString());
                    task.Status = sqlReader["Status"].ToString().Trim();
                }
            }

            command.Connection.Close();

            return task;
        }

        //Gets a customer with a specific id from the TTRMDCS database
        public Customer GetCustomer(int customer_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Klant_ID = @CustomerId", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@CustomerId", customer_Id));
            command.Connection.Open();

            Customer customer = new Customer();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString().Trim();
                    customer.Addres = sqlReader["Adres"].ToString().Trim();
                    customer.Zipcode = sqlReader["Postcode"].ToString().Trim();
                    customer.Residence = sqlReader["Woonplaats"].ToString().Trim();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                }
            }

            command.Connection.Close();

            return customer;
        }

        //Gets a customer with a specific id from the TCLOAN database
        public Customer GetCustomerTCLOAN(int customer_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Klant_ID = @CustomerId", sqlConnectionTCLOAN);
            command.Parameters.Add(new SqlParameter("@CustomerId", customer_Id));
            command.Connection.Open();

            Customer customer = new Customer();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString().Trim();
                    customer.Addres = sqlReader["Adres"].ToString().Trim();
                    customer.Zipcode = sqlReader["Postcode"].ToString().Trim();
                    customer.Residence = sqlReader["Woonplaats"].ToString().Trim();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                }
            }

            command.Connection.Close();

            return customer;
        }

        //Gets a list of customers
        public List<Customer> GetCustomers()
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Partner = 0", sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<Customer> customers = new List<Customer>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Customer customer = new Customer();
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString();
                    customer.Addres = sqlReader["Adres"].ToString();
                    customer.Zipcode = sqlReader["Postcode"].ToString();
                    customer.Residence = sqlReader["Woonplaats"].ToString();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                    customers.Add(customer);
                }
            }

            command.Connection.Close();
            return customers;
        }

        //Gets a list of customers with specific names
        public List<Customer> GetCustomersByName(string name)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Naam LIKE @Name AND Partner = 0", sqlConnectionTCLOAN);
            command.Parameters.Add(new SqlParameter("@Name", name + "%"));
            command.Connection.Open();

            List<Customer> customers = new List<Customer>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Customer customer = new Customer();
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString();
                    customer.Addres = sqlReader["Adres"].ToString();
                    customer.Zipcode = sqlReader["Postcode"].ToString();
                    customer.Residence = sqlReader["Woonplaats"].ToString();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                    customers.Add(customer);
                }
            }

            command.Connection.Close();
            return customers;
        }

        //Gets a list of customers and parners form the TTRMDCS database
        public List<Customer> GetCustomersAndPartners()
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer", sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<Customer> customers = new List<Customer>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Customer customer = new Customer();
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString();
                    customer.Addres = sqlReader["Adres"].ToString();
                    customer.Zipcode = sqlReader["Postcode"].ToString();
                    customer.Residence = sqlReader["Woonplaats"].ToString();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                    customers.Add(customer);
                }
            }

            command.Connection.Close();

            return customers;
        }

        //Gets a list of customers and parners form the TCLOAN database
        public List<Customer> GetCustomersAndPartnersTCLOAN()
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer", sqlConnectionTCLOAN);
            command.Connection.Open();

            List<Customer> customers = new List<Customer>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Customer customer = new Customer();
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString();
                    customer.Addres = sqlReader["Adres"].ToString();
                    customer.Zipcode = sqlReader["Postcode"].ToString();
                    customer.Residence = sqlReader["Woonplaats"].ToString();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                    customers.Add(customer);
                }
            }

            command.Connection.Close();

            return customers;
        }

        //Gets a list of customers and parner with specific names
        public List<Customer> GetCustomersAndPartnersByName(string name)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Naam LIKE @Name", sqlConnectionTCLOAN);
            command.Parameters.Add(new SqlParameter("@Name", name + "%"));
            command.Connection.Open();

            List<Customer> customers = new List<Customer>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Customer customer = new Customer();
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString();
                    customer.Addres = sqlReader["Adres"].ToString();
                    customer.Zipcode = sqlReader["Postcode"].ToString();
                    customer.Residence = sqlReader["Woonplaats"].ToString();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                    customers.Add(customer);
                }
            }

            command.Connection.Close();
            return customers;
        }

        //Gets a list the customers linked to a specific task
        public List<Customer> GetCustomersFromTask(Task task)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Tasks_Customers WHERE Task_Id = " + task.Id.ToString(), sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<int> customer_Ids = new List<int>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    customer_Ids.Add(int.Parse(sqlReader["Customer_Id"].ToString()));
                }
            }

            command.Connection.Close();

            if(customer_Ids.Count != 0)
            {
                string idsQuery = "";

                idsQuery += "Klant_ID in (";
                for (int i = 0; i < customer_Ids.Count; i++)
                {
                    idsQuery += "'" + customer_Ids[i] + "'";
                    if (i != customer_Ids.Count - 1)
                    {
                        idsQuery += ",";
                    }
                }
                idsQuery += ")";

                SqlCommand tasksCommand = new SqlCommand("SELECT * FROM Customer WHERE " + idsQuery + "", sqlConnectionTTRMDCS);
                tasksCommand.Connection.Open();

                List<Customer> customers = new List<Customer>();

                using (SqlDataReader sqlReader = tasksCommand.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        Customer customer = new Customer();
                        customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                        customer.Name = sqlReader["Naam"].ToString();
                        customer.Addres = sqlReader["Adres"].ToString();
                        customer.Zipcode = sqlReader["Postcode"].ToString();
                        customer.Residence = sqlReader["Woonplaats"].ToString();
                        customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                        customers.Add(customer);
                    }
                }

                tasksCommand.Connection.Close();
                return customers;
            }
            else
            {
                return null;
            }
        }

        //Gets a list the contactpersons linked to a specific task
        public List<Contactperson> GetContactpersonsFromTask(Task task)
        {
            //SqlCommand command = new SqlCommand("SELECT * FROM Reports_Tasks WHERE Report_Id = @ReportId", sqlConnectionTTRMDCS);
            //command.Parameters.Add(new SqlParameter("@ReportId", report.Id));
            SqlCommand command = new SqlCommand("SELECT * FROM Tasks_Contactpersons WHERE Task_Id = " + task.Id.ToString(), sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<int> contactpersons_Ids = new List<int>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    contactpersons_Ids.Add(int.Parse(sqlReader["Contactperson_Id"].ToString()));
                }
            }

            command.Connection.Close();

            if (contactpersons_Ids.Count != 0)
            {
                string idsQuery = "";

                idsQuery += "ContPers_ID in (";
                for (int i = 0; i < contactpersons_Ids.Count; i++)
                {
                    idsQuery += "'" + contactpersons_Ids[i] + "'";
                    if (i != contactpersons_Ids.Count - 1)
                    {
                        idsQuery += ",";
                    }
                }
                idsQuery += ")";

                SqlCommand tasksCommand = new SqlCommand("SELECT * FROM ContPers WHERE " + idsQuery + "", sqlConnectionTTRMDCS);
                tasksCommand.Connection.Open();

                List<Contactperson> contactpersons = new List<Contactperson>();

                using (SqlDataReader sqlReader = tasksCommand.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        Contactperson contactperson = new Contactperson();
                        contactperson.Id = int.Parse(sqlReader["ContPers_ID"].ToString());
                        contactperson.Name = sqlReader["Naam"].ToString();
                        contactperson.Email = sqlReader["email"].ToString();
                        contactperson.Telephonenumber = sqlReader["telefoon"].ToString();
                        contactperson.Accountmanager = Convert.ToBoolean(sqlReader["AccMan"].ToString());
                        contactpersons.Add(contactperson);
                    }
                }

                tasksCommand.Connection.Close();
                return contactpersons;
            }
            else
            {
                return null;
            }
        }

        //Gets a list the contactpersons linked to a specific customer
        public List<Contactperson> GetContactpersonsFromCustomer(Customer customer)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Kant_ContPers WHERE Klant_ID = " + customer.Id.ToString(), sqlConnectionTTRMDCS);
            command.Connection.Open();

            List<int> contactpersons_Ids = new List<int>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    contactpersons_Ids.Add(int.Parse(sqlReader["ContPers_ID"].ToString()));
                }
            }

            command.Connection.Close();

            if (contactpersons_Ids.Count != 0)
            {
                string idsQuery = "";

                idsQuery += "ContPers_ID in (";
                for (int i = 0; i < contactpersons_Ids.Count; i++)
                {
                    idsQuery += "'" + contactpersons_Ids[i] + "'";
                    if (i != contactpersons_Ids.Count - 1)
                    {
                        idsQuery += ",";
                    }
                }
                idsQuery += ")";

                SqlCommand customersCommand = new SqlCommand("SELECT * FROM ContPers WHERE " + idsQuery + "", sqlConnectionTTRMDCS);
                customersCommand.Connection.Open();

                List<Contactperson> contactpersons = new List<Contactperson>();

                using (SqlDataReader sqlReader = customersCommand.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        Contactperson contactperson = new Contactperson();
                        contactperson.Id = int.Parse(sqlReader["ContPers_ID"].ToString());
                        contactperson.Name = sqlReader["Naam"].ToString();
                        contactperson.Email = sqlReader["email"].ToString();
                        contactperson.Telephonenumber = sqlReader["telefoon"].ToString();
                        contactperson.Accountmanager = Convert.ToBoolean(sqlReader["AccMan"].ToString());
                        contactpersons.Add(contactperson);
                    }
                }

                customersCommand.Connection.Close();
                return contactpersons;
            }
            else
            {
                return null;
            }
        }

        //Changes the value partner in the customer table of a specific customer to change it to a partner
        public void ChangeCustomerToPartner(Customer customer)
        {
            SqlCommand command = new SqlCommand("UPDATE Customer SET Partner = 1 WHERE Klant_ID = @Id", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Id", customer.Id));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Gets a contactperson with a specific id form the TTRMDCS database
        public Contactperson GetContactperson(int contactperson_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM ContPers WHERE ContPers_ID = @ContactpersonId", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@ContactpersonId", contactperson_Id));
            command.Connection.Open();

            Contactperson contactperson = new Contactperson();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    contactperson.Id = int.Parse(sqlReader["ContPers_ID"].ToString());
                    contactperson.Name = sqlReader["Naam"].ToString();
                    contactperson.Email = sqlReader["email"].ToString();
                    contactperson.Telephonenumber = sqlReader["telefoon"].ToString();
                    contactperson.Accountmanager = Convert.ToBoolean(sqlReader["AccMan"].ToString());
                }
            }

            command.Connection.Close();

            return contactperson;
        }

        //Gets a contactperson with a specific id form the TCLOAN database
        public Contactperson GetContactpersonTCLOAN(int contactperson_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM ContPers WHERE ContPers_ID = @ContactpersonId", sqlConnectionTCLOAN);
            command.Parameters.Add(new SqlParameter("@ContactpersonId", contactperson_Id));
            command.Connection.Open();

            Contactperson contactperson = new Contactperson();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    contactperson.Id = int.Parse(sqlReader["ContPers_ID"].ToString());
                    contactperson.Name = sqlReader["Naam"].ToString();
                    contactperson.Email = sqlReader["email"].ToString();
                    contactperson.Telephonenumber = sqlReader["telefoon"].ToString();
                    contactperson.Accountmanager = Convert.ToBoolean(sqlReader["AccMan"].ToString());
                }
            }

            command.Connection.Close();

            return contactperson;
        }

        //Gets a list of contactpersons form the TTRMDCS database
        public List<Contactperson> GetContactpersons()
        {
            SqlCommand commandTTRMDCS = new SqlCommand("SELECT * FROM ContPers", sqlConnectionTTRMDCS);
            commandTTRMDCS.Connection.Open();

            List<Contactperson> contactpersons = new List<Contactperson>();

            using (SqlDataReader sqlReader = commandTTRMDCS.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Contactperson contactperson = new Contactperson();
                    contactperson.Id = int.Parse(sqlReader["ContPers_ID"].ToString());
                    contactperson.Name = sqlReader["Naam"].ToString();
                    contactperson.Email = sqlReader["email"].ToString();
                    contactperson.Telephonenumber = sqlReader["telefoon"].ToString();
                    contactperson.Accountmanager = Convert.ToBoolean(sqlReader["AccMan"].ToString());
                    contactpersons.Add(contactperson);
                }
            }

            commandTTRMDCS.Connection.Close();

            return contactpersons;
        }

        //Gets a list of contactpersons form the TCLOAN database
        public List<Contactperson> GetContactpersonsTCLOAN()
        {
            SqlCommand commandTCLOAN = new SqlCommand("SELECT * FROM ContPers", sqlConnectionTCLOAN);
            commandTCLOAN.Connection.Open();

            List<Contactperson> contactpersons = new List<Contactperson>();

            using (SqlDataReader sqlReader = commandTCLOAN.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Contactperson contactperson = new Contactperson();
                    contactperson.Id = int.Parse(sqlReader["ContPers_ID"].ToString());
                    contactperson.Name = sqlReader["Naam"].ToString();
                    contactperson.Email = sqlReader["email"].ToString();
                    contactperson.Telephonenumber = sqlReader["telefoon"].ToString();
                    contactperson.Accountmanager = Convert.ToBoolean(sqlReader["AccMan"].ToString());
                    contactpersons.Add(contactperson);
                }
            }

            commandTCLOAN.Connection.Close();

            return contactpersons;
        }

        //Gets a list of contactpersons with specific names
        public List<Contactperson> GetContactpersonsByName(string name)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM ContPers WHERE Naam LIKE @Name", sqlConnectionTCLOAN);
            command.Parameters.Add(new SqlParameter("@Name", name + "%"));
            command.Connection.Open();

            List<Contactperson> contactpersons = new List<Contactperson>();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    Contactperson contactperson = new Contactperson();
                    contactperson.Id = int.Parse(sqlReader["ContPers_ID"].ToString());
                    contactperson.Name = sqlReader["Naam"].ToString();
                    contactperson.Email = sqlReader["email"].ToString();
                    contactperson.Telephonenumber = sqlReader["telefoon"].ToString();
                    contactperson.Accountmanager = Convert.ToBoolean(sqlReader["AccMan"].ToString());
                    contactpersons.Add(contactperson);
                }
            }

            command.Connection.Close();
            return contactpersons;
        }

        //Gets a list of partners
        public List<Customer> GetPartners()
        {
            List<Customer> partners = new List<Customer> { };
            return partners;
        }

        //Gets a partner wiith a specific id
        public Customer GetPartner(int partner_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Customer WHERE Klant_ID = @PartnerId", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@PartnerId", partner_Id));
            command.Connection.Open();

            Customer customer = new Customer();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    customer.Id = int.Parse(sqlReader["Klant_ID"].ToString());
                    customer.Name = sqlReader["Naam"].ToString().Trim();
                    customer.Addres = sqlReader["Adres"].ToString().Trim();
                    customer.Zipcode = sqlReader["Postcode"].ToString().Trim();
                    customer.Residence = sqlReader["Woonplaats"].ToString().Trim();
                    customer.Partner = Convert.ToBoolean(sqlReader["Partner"].ToString());
                }
            }

            command.Connection.Close();

            return customer;
        }

        //Gets a list of reports
        public List<Report> GetReports()
        {
            List<Report> reports = new List<Report> { };
            return reports;
        }

        //Gets a report with a specific id
        public Report GetReport(int report_Id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Reports WHERE Id = @ReportID", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@ReportID", report_Id));
            command.Connection.Open();

            Report report = new Report();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    report.Id = int.Parse(sqlReader["Id"].ToString());
                    report.Date = Convert.ToDateTime(sqlReader["Date"].ToString());
                }
            }

            command.Connection.Close();

            return report;
        }

        //Gets a repport that falls in a specific year and month
        public Report GetReportFromYearAndMonth(string year, string month)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Reports WHERE Date >= '" + year + "-" + month.Split('-')[1] + "-01'  AND Date <= '" + year + "-" + month.Split('-')[1] + "-31'", sqlConnectionTTRMDCS);
            command.Connection.Open();

            Report report = null;

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    report = new Report();
                    report.Id = int.Parse(sqlReader["Id"].ToString());
                    report.Date = Convert.ToDateTime(sqlReader["Date"].ToString());
                }
            }

            command.Connection.Close();
            return report;
        }

        //Adds a task
        public void AddTask(Task task)
        {
            SqlCommand command = new SqlCommand("INSERT INTO Tasks (Description, Date, Visit, Research, Conference_call, Status) " +
                "VALUES (@Description, @Date, @Visit, @Research, @Conference_call, @Status)", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Description", task.Description));
            command.Parameters.Add(new SqlParameter("@Date", task.Date));
            command.Parameters.Add(new SqlParameter("@Visit", task.Visit));
            command.Parameters.Add(new SqlParameter("@Research", task.Research));
            command.Parameters.Add(new SqlParameter("@Conference_call", task.Conference_call));
            command.Parameters.Add(new SqlParameter("@Status", task.Status));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Adds a report
        public void AddReport(Report report)
        {
            SqlCommand command = new SqlCommand("INSERT INTO Reports (Date) VALUES (@Date)", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Date", report.Date));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Adds a link to specific tasks and a report
        public void AddTasksToReport(List<Task> tasks, Report report)
        {
            string date = "'" + report.Date.Year + "-" + report.Date.Month + "-" + report.Date.Day + "'";
            SqlCommand command = new SqlCommand("SELECT Id FROM Reports WHERE Date = " + date + "", sqlConnectionTTRMDCS);
            command.Connection.Open();
            int id = (int)command.ExecuteScalar();
            command.Connection.Close();

            for(int i = 0; i < tasks.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO Reports_Tasks (Report_Id, Task_Id) VALUES (@Report_Id, @Task_Id)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Report_Id", id));
                reportCommand.Parameters.Add(new SqlParameter("@Task_Id", tasks[i].Id));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Adds a link to specific customers and a task
        public void AddCustomersToTask(List<Customer> customers, Task task)
        {
            //SqlCommand command = new SqlCommand("SELECT Id FROM Tasks WHERE Description = @Description", sqlConnectionTTRMDCS);
            //command.Parameters.Add("@Description", task.Description);
            //command.Connection.Open();
            //int id = (int)command.ExecuteScalar();
            //command.Connection.Close();

            //for (int i = 0; i < customers.Count; i++)
            //{
            //    SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Customers (Task_Id, Customer_Id) VALUES (@Task_Id, @Customer_Id)", sqlConnectionTTRMDCS);
            //    reportCommand.Parameters.Add(new SqlParameter("@Task_Id", id));
            //    reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customers[i].Id));
            //    reportCommand.Connection.Open();
            //    reportCommand.ExecuteScalar();
            //    reportCommand.Connection.Close();
            //}

            SqlCommand command = new SqlCommand("SELECT Id FROM Tasks WHERE Description = @Description", sqlConnectionTTRMDCS);
            command.Parameters.Add("@Description", task.Description);
            command.Connection.Open();
            int id = (int)command.ExecuteScalar();
            command.Connection.Close();

            for (int i = 0; i < customers.Count; i++)
            {
                SqlCommand customerCommand = new SqlCommand("INSERT INTO Customer (Naam, Adres, Postcode, Woonplaats, Partner) VALUES (@Name, @Addres, @Zipcode, @Residence, @Partner)", sqlConnectionTTRMDCS);
                customerCommand.Parameters.Add(new SqlParameter("@Name", customers[i].Name));
                customerCommand.Parameters.Add(new SqlParameter("@Addres", customers[i].Addres));
                customerCommand.Parameters.Add(new SqlParameter("@Zipcode", customers[i].Zipcode));
                customerCommand.Parameters.Add(new SqlParameter("@Residence", customers[i].Residence));
                customerCommand.Parameters.Add(new SqlParameter("@Partner", false));
                customerCommand.Connection.Open();
                customerCommand.ExecuteScalar();
                customerCommand.Connection.Close();
            }

            List<int> customerIds = new List<int> { };

            for (int i = 0; i < customers.Count; i++)
            {
                SqlCommand idCommand = new SqlCommand("SELECT Klant_ID FROM Customer WHERE Naam = @Name AND Adres = @Addres", sqlConnectionTTRMDCS);
                idCommand.Parameters.Add("@Name", customers[i].Name);
                idCommand.Parameters.Add("@Addres", customers[i].Addres);
                idCommand.Connection.Open();
                customerIds.Add((int)idCommand.ExecuteScalar());
                idCommand.Connection.Close();
            }

            for (int i = 0; i < customerIds.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Customers (Task_Id, Customer_Id) VALUES (@Task_Id, @Customer_Id)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Task_Id", id));
                reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customerIds[i]));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Adds a link to specific customers and a task with a specific id
        public void AddCustomersToTaskWithId(List<Customer> customers, int task_Id)
        {
            for (int i = 0; i < customers.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Customers (Task_Id, Customer_Id) VALUES (@Task_Id, @Customer_Id)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Task_Id", task_Id));
                reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customers[i].Id));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Removes a link to specific customers from a task
        public void RemoveCustomersFromTask(List<Customer> customers, Task task)
        {
            //SqlCommand command = new SqlCommand("SELECT Id FROM Tasks WHERE Id = @TaskId", sqlConnectionTTRMDCS);
            //command.Parameters.Add("@TaskId", task.Id);
            //command.Connection.Open();
            //int id = (int)command.ExecuteScalar();
            //command.Connection.Close();

            for (int i = 0; i < customers.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("DELETE FROM Tasks_Customers WHERE @Task_Id = Task_Id AND Customer_Id = @Customer_Id", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Task_Id", task.Id));
                reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customers[i].Id));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Adds a link to specific contactpersons and a task
        public void AddContactpersonsToTask(List<Contactperson> contactpersons, Task task)
        {
            //SqlCommand command = new SqlCommand("SELECT Id FROM Tasks WHERE Description = @Description", sqlConnectionTTRMDCS);
            //command.Parameters.Add("@Description", task.Description);
            //command.Connection.Open();
            //int id = (int)command.ExecuteScalar();
            //command.Connection.Close();

            //for (int i = 0; i < contactpersons.Count; i++)
            //{
            //    SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Contactpersons (Task_Id, Contactperson_Id) VALUES (@Task_Id, @Contactperson_Id)", sqlConnectionTTRMDCS);
            //    reportCommand.Parameters.Add(new SqlParameter("@Task_Id", id));
            //    reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersons[i].Id));
            //    reportCommand.Connection.Open();
            //    reportCommand.ExecuteScalar();
            //    reportCommand.Connection.Close();
            //}

            SqlCommand command = new SqlCommand("SELECT Id FROM Tasks WHERE Description = @Description", sqlConnectionTTRMDCS);
            command.Parameters.Add("@Description", task.Description);
            command.Connection.Open();
            int id = (int)command.ExecuteScalar();
            command.Connection.Close();

            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand contactpersonCommand = new SqlCommand("INSERT INTO Contpers (Naam, email, telefoon, AccMan) VALUES (@Name, @Email, @Telephonenumber, @Accountmanager)", sqlConnectionTTRMDCS);
                contactpersonCommand.Parameters.Add(new SqlParameter("@Name", contactpersons[i].Name));
                contactpersonCommand.Parameters.Add(new SqlParameter("@Email", contactpersons[i].Email));
                contactpersonCommand.Parameters.Add(new SqlParameter("@Telephonenumber", contactpersons[i].Telephonenumber));
                contactpersonCommand.Parameters.Add(new SqlParameter("@Accountmanager", contactpersons[i].Accountmanager));
                contactpersonCommand.Connection.Open();
                contactpersonCommand.ExecuteScalar();
                contactpersonCommand.Connection.Close();
            }

            List<int> contactpersonIds = new List<int> { };

            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand idCommand = new SqlCommand("SELECT ContPers_ID FROM Contpers WHERE Naam = @Name AND email = @Email", sqlConnectionTTRMDCS);
                idCommand.Parameters.Add("@Name", contactpersons[i].Name);
                idCommand.Parameters.Add("@Email", contactpersons[i].Email);
                idCommand.Connection.Open();
                contactpersonIds.Add((int)idCommand.ExecuteScalar());
                idCommand.Connection.Close();
            }

            for (int i = 0; i < contactpersonIds.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Contactpersons (Task_Id, Contactperson_Id) VALUES (@Task_Id, @Contactperson_Id)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Task_Id", id));
                reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersonIds[i]));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Adds a link to specific contactpersons and a task with a specific id
        public void AddContactpersonsToTaskWithId(List<Contactperson> contactpersons, int task_Id)
        {
            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Contactpersons (Task_Id, Contactperson_Id) VALUES (@Task_Id, @Contactperson_Id)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Task_Id", task_Id));
                reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersons[i].Id));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Removes a link to specific contactpersons from a task
        public void RemoveContactpersonsFromTask(List<Contactperson> contactpersons, Task task)
        {
            //SqlCommand command = new SqlCommand("SELECT Id FROM Tasks WHERE Id = @TaskId", sqlConnectionTTRMDCS);
            //command.Parameters.Add("@TaskId", task.Id);
            //command.Connection.Open();
            //int id = (int)command.ExecuteScalar();
            //command.Connection.Close();

            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("DELETE FROM Tasks_Contactpersons WHERE Task_Id = @Task_Id AND Contactperson_Id = @Contactperson_Id", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Task_Id", task.Id));
                reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersons[i].Id));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Adds a link to specific contactpersons and a customer with a specific id
        public void AddContactpersonsToCustomerWithId(List<Contactperson> contactpersons, int customer_Id)
        {
            //for (int i = 0; i < contactpersons.Count; i++)
            //{
            //    SqlCommand reportCommand = new SqlCommand("INSERT INTO Kant_ContPers (Klant_ID, ContPers_ID) VALUES (@Customer_Id, @Contactperson_Id)", sqlConnectionTTRMDCS);
            //    reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customer_Id));
            //    reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersons[i].Id));
            //    reportCommand.Connection.Open();
            //    reportCommand.ExecuteScalar();
            //    reportCommand.Connection.Close();
            //}

            //for (int i = 0; i < contactpersons.Count; i++)
            //{
            //    SqlCommand reportCommand = new SqlCommand("INSERT INTO ContPers (Naam, email, telefoon, AccMan) VALUES (@Name, @Email, @Telephonenumber, @Accountmanager)", sqlConnectionTTRMDCS);
            //    reportCommand.Parameters.Add(new SqlParameter("@Name", contactpersons[i].Name));
            //    reportCommand.Parameters.Add(new SqlParameter("@Email", contactpersons[i].Email));
            //    reportCommand.Parameters.Add(new SqlParameter("@Telephonenumber", contactpersons[i].Telephonenumber));
            //    reportCommand.Parameters.Add(new SqlParameter("@Accountmanager", contactpersons[i].Accountmanager));
            //    reportCommand.Connection.Open();
            //    reportCommand.ExecuteScalar();
            //    reportCommand.Connection.Close();
            //}

            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO ContPers (Naam, email, telefoon, AccMan) VALUES (@Name, @Email, @Telephonenumber, @Accountmanager)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Name", contactpersons[i].Name));
                reportCommand.Parameters.Add(new SqlParameter("@Email", contactpersons[i].Email));
                reportCommand.Parameters.Add(new SqlParameter("@Telephonenumber", contactpersons[i].Telephonenumber));
                reportCommand.Parameters.Add(new SqlParameter("@Accountmanager", contactpersons[i].Accountmanager));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }

            List<int> contactpersonsIds = new List<int> { };

            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand idCommand = new SqlCommand("SELECT ContPers_ID FROM ContPers WHERE Naam = @Name AND email = @Email", sqlConnectionTTRMDCS);
                idCommand.Parameters.Add("@Name", contactpersons[i].Name);
                idCommand.Parameters.Add("@Email", contactpersons[i].Email);
                idCommand.Connection.Open();
                contactpersonsIds.Add((int)idCommand.ExecuteScalar());
                idCommand.Connection.Close();
            }

            for (int i = 0; i < contactpersonsIds.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO Kant_ContPers (Klant_ID, ContPers_ID) VALUES (@Customer_Id, @Contactperson_Id)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customer_Id));
                reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersonsIds[i]));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Removes a link to specific contactpersons from a customer with a specific id
        public void RemoveContactpersonsFromCustomer(List<Contactperson> contactpersons, Customer customer)
        {
            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("DELETE FROM Kant_ContPers WHERE Klant_ID = @Customer_Id AND ContPers_ID = @Contactperson_Id", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customer.Id));
                reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersons[i].Id));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Adds a link to specific contactpersons and a customer
        public void AddContactpersonsToCustomer(List<Contactperson> contactpersons, Customer customer)
        {
            SqlCommand command = new SqlCommand("SELECT Klant_ID FROM Customer WHERE Naam = @Name AND Adres = @Addres", sqlConnectionTTRMDCS);
            command.Parameters.Add("@Name", customer.Name);
            command.Parameters.Add("@Addres", customer.Addres);
            command.Connection.Open();
            int id = (int)command.ExecuteScalar();
            command.Connection.Close();

            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO ContPers (Naam, email, telefoon, AccMan) VALUES (@Name, @Email, @Telephonenumber, @Accountmanager)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Name", contactpersons[i].Name));
                reportCommand.Parameters.Add(new SqlParameter("@Email", contactpersons[i].Email));
                reportCommand.Parameters.Add(new SqlParameter("@Telephonenumber", contactpersons[i].Telephonenumber));
                reportCommand.Parameters.Add(new SqlParameter("@Accountmanager", contactpersons[i].Accountmanager));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }

            List<int> ids = new List<int> { };
            for (int i = 0; i < contactpersons.Count; i++)
            {
                SqlCommand contactperonCommand = new SqlCommand("SELECT ContPers_ID FROM ContPers WHERE Naam = @Name AND email = @Email", sqlConnectionTTRMDCS);
                contactperonCommand.Parameters.Add("@Name", contactpersons[i].Name);
                contactperonCommand.Parameters.Add("@Email", contactpersons[i].Email);
                contactperonCommand.Connection.Open();
                ids.Add((int)contactperonCommand.ExecuteScalar());
                contactperonCommand.Connection.Close();
            }

            for (int i = 0; i < ids.Count; i++)
            {
                SqlCommand reportCommand = new SqlCommand("INSERT INTO Kant_ContPers (Klant_ID, ContPers_ID) VALUES (@Customer_Id, @Contactperson_Id)", sqlConnectionTTRMDCS);
                reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", id));
                reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", ids[i]));
                reportCommand.Connection.Open();
                reportCommand.ExecuteScalar();
                reportCommand.Connection.Close();
            }
        }

        //Adds a link to a specific customer and a task
        public void AddCustomerToTask(Customer customer, Task task)
        {
            SqlCommand taskCommand = new SqlCommand("SELECT Id FROM Tasks WHERE Description = @Description", sqlConnectionTTRMDCS);
            taskCommand.Parameters.Add("@Description", task.Description);
            taskCommand.Connection.Open();
            int taskId = (int)taskCommand.ExecuteScalar();
            taskCommand.Connection.Close();

            SqlCommand customerCommand = new SqlCommand("SELECT Klant_ID FROM Customer WHERE Naam = @Name", sqlConnectionTTRMDCS);
            customerCommand.Parameters.Add("@Name", customer.Name);
            customerCommand.Connection.Open();
            int customerId = (int)customerCommand.ExecuteScalar();
            customerCommand.Connection.Close();

            SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Customers (Task_Id, Customer_Id) VALUES (@Task_Id, @Customer_Id)", sqlConnectionTTRMDCS);
            reportCommand.Parameters.Add(new SqlParameter("@Task_Id", taskId));
            reportCommand.Parameters.Add(new SqlParameter("@Customer_Id", customerId));
            reportCommand.Connection.Open();
            reportCommand.ExecuteScalar();
            reportCommand.Connection.Close();
        }

        //Adds a link to a specific contactperson and a task
        public void AddContactpersonToTask(Contactperson contactperson, Task task)
        {
            SqlCommand taskCommand = new SqlCommand("SELECT Id FROM Tasks WHERE Description = @Description", sqlConnectionTTRMDCS);
            taskCommand.Parameters.Add("@Description", task.Description);
            taskCommand.Connection.Open();
            int taskId = (int)taskCommand.ExecuteScalar();
            taskCommand.Connection.Close();

            SqlCommand contactpersonCommand = new SqlCommand("SELECT ContPers_ID FROM ContPers WHERE Naam = @Name", sqlConnectionTTRMDCS);
            contactpersonCommand.Parameters.Add("@Name", contactperson.Name);
            contactpersonCommand.Connection.Open();
            int contactpersonId = (int)contactpersonCommand.ExecuteScalar();
            contactpersonCommand.Connection.Close();

            SqlCommand reportCommand = new SqlCommand("INSERT INTO Tasks_Contactpersons (Task_Id, Contactperson_Id) VALUES (@Task_Id, @Contactperson_Id)", sqlConnectionTTRMDCS);
            reportCommand.Parameters.Add(new SqlParameter("@Task_Id", taskId));
            reportCommand.Parameters.Add(new SqlParameter("@Contactperson_Id", contactpersonId));
            reportCommand.Connection.Open();
            reportCommand.ExecuteScalar();
            reportCommand.Connection.Close();
        }

        //Checks the escistance of a report
        public bool CheckReportExcistence(string year, string month/*DateTime date*/)
        {
            //string dateQuery = "'" + date.Date.Year + "-" + date.Date.Month + "-" + date.Date.Day + "'";
            //SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Reports WHERE Date = " + dateQuery + "", sqlConnectionTTRMDCS);
            //command.Connection.Open();
            //int count = (int)command.ExecuteScalar();
            //command.Connection.Close();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Reports WHERE Date >= '" + year + "-" + month + "-01'  AND Date <= '" + year + "-" + month + "-31'", sqlConnectionTTRMDCS);
            command.Connection.Open();
            int count = (int)command.ExecuteScalar();
            command.Connection.Close();

            if (count > 0)
            {
                return true;
            }
            return false;        
        }

        //Adds a user
        public void AddUser(User user)
        {
            SqlCommand command = new SqlCommand("INSERT INTO Users (Username, Password, Email, Role) " +
                "VALUES (@Username, @Password, @Email, @Role)", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Username", user.Username));
            command.Parameters.Add(new SqlParameter("@Password", user.Password));
            command.Parameters.Add(new SqlParameter("@Email", user.Email));
            command.Parameters.Add(new SqlParameter("@Role", user.Role));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Adds a customer
        public void AddCustomer(Customer customer)
        {
            SqlCommand command = new SqlCommand("INSERT INTO Customer (Naam, Adres, Postcode, Woonplaats, Partner) VALUES (@Name, @Addres, @Zipcode, @Residence, @Partner)", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Name", customer.Name));
            command.Parameters.Add(new SqlParameter("@Addres", customer.Addres));
            command.Parameters.Add(new SqlParameter("@Zipcode", customer.Zipcode));
            command.Parameters.Add(new SqlParameter("@Residence", customer.Residence));
            command.Parameters.Add(new SqlParameter("@Partner", false));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Adds a customer with only a name
        public void AddCustomerStart(Customer customer)
        {
            SqlCommand command = new SqlCommand("INSERT INTO Customer (Naam, Partner) VALUES (@Name, @Partner)", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Name", customer.Name));
            command.Parameters.Add(new SqlParameter("@Partner", false));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Adds a partner
        public void AddPartner(Customer customer)
        {
            SqlCommand command = new SqlCommand("INSERT INTO Customer (Naam, Adres, Postcode, Woonplaats, Partner) VALUES (@Name, @Addres, @Zipcode, @Residence, @Partner)", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Name", customer.Name));
            command.Parameters.Add(new SqlParameter("@Addres", customer.Addres));
            command.Parameters.Add(new SqlParameter("@Zipcode", customer.Zipcode));
            command.Parameters.Add(new SqlParameter("@Residence", customer.Residence));
            command.Parameters.Add(new SqlParameter("@Partner", true));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Adds a contactperson
        public void AddContactperson(Contactperson contactperson)
        {
            SqlCommand command = new SqlCommand("INSERT INTO Contpers (Naam, email, telefoon, AccMan) VALUES (@Name, @Email, @Telephonenumber, @Accountmanager)", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Name", contactperson.Name));
            command.Parameters.Add(new SqlParameter("@Email", contactperson.Email));
            command.Parameters.Add(new SqlParameter("@Telephonenumber", contactperson.Telephonenumber));
            command.Parameters.Add(new SqlParameter("@Accountmanager", contactperson.Accountmanager));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Changes a task
        public void EditTask(Task task, int task_Id)
        {
            SqlCommand command = new SqlCommand("UPDATE Tasks SET Description = @Description, Date = @Date, Visit = @Visit, Research = @Research, Conference_call = @Conference_call, Status = @Status WHERE Id = @TaskId", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@TaskId", task_Id));
            command.Parameters.Add(new SqlParameter("@Description", task.Description));
            command.Parameters.Add(new SqlParameter("@Date", task.Date));
            command.Parameters.Add(new SqlParameter("@Visit", task.Visit));
            command.Parameters.Add(new SqlParameter("@Research", task.Research));
            command.Parameters.Add(new SqlParameter("@Conference_call", task.Conference_call));
            command.Parameters.Add(new SqlParameter("@Status", task.Status));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Changes a customer
        public void EditCustomer(Customer customer, int customer_Id)
        {
            SqlCommand command = new SqlCommand("UPDATE Customer SET Naam = @Name, Adres = @Addres, Postcode = @Zipcode, Woonplaats = @Residence WHERE Klant_ID = @CustomerId", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@CustomerId", customer_Id));
            command.Parameters.Add(new SqlParameter("@Name", customer.Name));
            command.Parameters.Add(new SqlParameter("@Addres", customer.Addres));
            command.Parameters.Add(new SqlParameter("@Zipcode", customer.Zipcode));
            command.Parameters.Add(new SqlParameter("@Residence", customer.Residence));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Changes a partner
        public void EditPartner(Customer customer, int partner_Id)
        {
            SqlCommand command = new SqlCommand("UPDATE Customer SET Naam = @Name, Adres = @Addres, Postcode = @Zipcode, Woonplaats = @Residence WHERE Klant_ID = @PartnerId", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@PartnerId", partner_Id));
            command.Parameters.Add(new SqlParameter("@Name", customer.Name));
            command.Parameters.Add(new SqlParameter("@Addres", customer.Addres));
            command.Parameters.Add(new SqlParameter("@Zipcode", customer.Zipcode));
            command.Parameters.Add(new SqlParameter("@Residence", customer.Residence));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //public bool Login(string username, string password)
        //{
        //    SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username AND Password = @Password", sqlConnectionTTRMDCS);
        //    command.Parameters.Add(new SqlParameter("@Username", username));
        //    command.Parameters.Add(new SqlParameter("@Password", password));
        //    command.Connection.Open();
        //    int count = (int)command.ExecuteScalar();
        //    command.Connection.Close();

        //    if(count == 0)
        //    {
        //        return false;
        //    }
        //    return true;
        //}

        //Gets a user with a specific username and password
        public User GetUser(string username, string password)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Users WHERE Username = @Username AND Password = @Password", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@Username", username));
            command.Parameters.Add(new SqlParameter("@Password", password));
            command.Connection.Open();

            User user = new User();

            using (SqlDataReader sqlReader = command.ExecuteReader())
            {
                while (sqlReader.Read())
                {
                    user.Id = int.Parse(sqlReader["Id"].ToString());
                    user.Username = sqlReader["Username"].ToString().Trim();
                    user.Password = sqlReader["Password"].ToString().Trim();
                    user.Email = sqlReader["Email"].ToString().Trim();
                    user.Role = sqlReader["Role"].ToString().Trim();
                }
            }

            //Task task = (Task)command.ExecuteScalar();
            command.Connection.Close();

            return user;
        }

        //Changes the password of a user
        public void EditUserPassword(string password)
        {
            SqlCommand command = new SqlCommand("UPDATE Users SET Password = @NewPassword WHERE Username = @Username AND Password = @Password", sqlConnectionTTRMDCS);
            command.Parameters.Add(new SqlParameter("@NewPassword", password));
            command.Parameters.Add(new SqlParameter("@Username", (System.Web.HttpContext.Current.Session["key"] as User).Username));
            command.Parameters.Add(new SqlParameter("@Password", (System.Web.HttpContext.Current.Session["key"] as User).Password));
            command.Connection.Open();
            command.ExecuteScalar();
            command.Connection.Close();
        }

        //Gets the instance of the databasehandler
        public static DatabaseHandler GetInstance()
        {
            if(Instance == null)
            {
                Instance = new DatabaseHandler();
            }
            return Instance;
        }
    }
}