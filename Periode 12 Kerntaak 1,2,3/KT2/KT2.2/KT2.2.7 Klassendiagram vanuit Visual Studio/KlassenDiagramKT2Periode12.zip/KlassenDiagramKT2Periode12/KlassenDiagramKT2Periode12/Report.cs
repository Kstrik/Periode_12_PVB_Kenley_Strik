﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class Report
    {
        public Report()
        {
            throw new System.NotImplementedException();
        }

        public Report(DateTime Date)
        {
            throw new System.NotImplementedException();
        }

        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public DateTime Date
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}