﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class RegistratiesController
    {
        public DatabaseHandler DatabaseHandler
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public IsAuthorized IsAuthorized
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public ActionResult TaakRegistreren()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult TaakRegistreren(Task task)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult SetTemplateCustomerName(string customerName)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSearchableCustomers()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetCustomerByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddSelectedCustomerItem(string customerId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSelectedCustomerItem()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult RemoveSelectedCustomerItem(string customerId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSearchableContactpersons()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetContactpersonsByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddSelectedContactpersonItem(string contactpersonId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSelectedContactpersons()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult RemoveSelectedContactpersonItem(string contactpersonId)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult KlantRegistreren()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult KlantRegistreren(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult PartnerRegistreren()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult PartnerRegistreren(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddContactPerson(string name, string email, string telephonenumber, string accountmanager)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult RemoveContactPerson(string contactPersonId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddCustomerToSelection(string customerId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetCustomers()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetOnlyCustomerByName(string name)
        {
            throw new System.NotImplementedException();
        }
    }
}