﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class OverzichtenController
    {
        public DatabaseHandler DatabaseHandler
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public IsAuthorized IsAuthorized
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public ActionResult OverzichtTaken()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetTasks(string year, string month, string status)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult OverzichtKlanten()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetCustomers(string name, string residence)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult OverzichtPartners()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetPartners(string name, string residence)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddContactpersonToSelection(string contactpersonId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetContactpersons()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetOnlyContactpersonsByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult EditTask(string taskId)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult TaakBewerken()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult TaakBewerken(Task task)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSearchableCustomers()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetCustomersByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddSelectedCustomers(string customerId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSelectedCustomers()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult RemoveSelectedCustomerItem(JsonResult customerId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSearchableContactpersons()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetContactpersonsByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddSelectedContactpersonItem(string contactpersonId)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetSlecetdContactpersons()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult RemoveSelectedContactpersonItem(string contactpersonId)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult EditCustomer(string customerId)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult KlantBewerken()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult KlantBewerken(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult EditPartner(string partnerId)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult PartnerBewerken()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult PartnerBewerken(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetContactpersonsList()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult AddContactPerson(string name, string email, string telephonenumber, string accountmanager)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult RemoveContactPerson(string contactperson_Id)
        {
            throw new System.NotImplementedException();
        }
    }
}