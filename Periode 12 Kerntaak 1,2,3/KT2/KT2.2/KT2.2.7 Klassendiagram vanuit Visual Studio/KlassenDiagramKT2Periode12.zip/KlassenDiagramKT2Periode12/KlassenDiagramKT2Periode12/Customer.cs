﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class Customer
    {
        public Customer()
        {
            throw new System.NotImplementedException();
        }

        public Customer(string Name, string Addres, string Zipcode, string Residence, bool Partner)
        {
            throw new System.NotImplementedException();
        }

        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Name
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Addres
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Zipcode
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Residence
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public bool Partner
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}