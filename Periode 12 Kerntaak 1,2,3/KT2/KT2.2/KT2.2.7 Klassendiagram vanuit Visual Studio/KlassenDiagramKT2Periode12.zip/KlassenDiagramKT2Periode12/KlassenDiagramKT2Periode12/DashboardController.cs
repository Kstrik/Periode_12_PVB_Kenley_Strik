﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class DashboardController
    {
        public DatabaseHandler DatabaseHandler
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public IsAuthorized IsAuthorized
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public ActionResult Dashboard()
        {
            throw new System.NotImplementedException();
        }
    }
}