﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class ProfielController
    {
        public DatabaseHandler DatabaseHandler
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public IsAuthorized IsAuthorized
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public ActionResult Index()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult Index(User user)
        {
            throw new System.NotImplementedException();
        }
    }
}