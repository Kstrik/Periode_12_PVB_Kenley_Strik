﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class DatabaseHandler
    {
        private DatabaseHandler()
        {
            throw new System.NotImplementedException();
        }

        private DatabaseHandler Instance
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public SqlConnection sqlConnectionTTRMDCS
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public SqlConnection sqlConnectionTCLOAN
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public List<Task> GetTasks()
        {
            throw new System.NotImplementedException();
        }

        public List<Task> GetTasksWithFilter(string year, string month, string status, string contactperson_Id)
        {
            throw new System.NotImplementedException();
        }

        public Lisy<Customer> GetCustomersWithFilter(string name, string residence, string contactperson_Id)
        {
            throw new System.NotImplementedException();
        }

        public List<Customer> GetPartnersWithFilter(string name, string residence, string contactperson_Id)
        {
            throw new System.NotImplementedException();
        }

        public List<Task> GetTasksFromYearAndMonth(string year, string month)
        {
            throw new System.NotImplementedException();
        }

        public List<Task> GetTasksFromReport(Report report)
        {
            throw new System.NotImplementedException();
        }

        public Task GetTask(int task_Id)
        {
            throw new System.NotImplementedException();
        }

        public Customer GetCustomer(int customer_Id)
        {
            throw new System.NotImplementedException();
        }

        public Customer GetCustomerTCLOAN(int customer_Id)
        {
            throw new System.NotImplementedException();
        }

        public List<Customer> GetCustomers()
        {
            throw new System.NotImplementedException();
        }

        public List<Customer> GetCustomersByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public List<Customer> GetCustomersAndPartners()
        {
            throw new System.NotImplementedException();
        }

        public List<Customer> GetCustomersAndPartnersTCLOAN()
        {
            throw new System.NotImplementedException();
        }

        public List<Customer> GetCustomersAndPartnersByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public List<Customer> GetCustomersFromTask(Task task)
        {
            throw new System.NotImplementedException();
        }

        public List<Contactperson> GetContactpersonsFromTask(Task task)
        {
            throw new System.NotImplementedException();
        }

        public List<Contactperson> GetContactpersonsFromCustomer(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public void ChangeCustomerToPartner(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public Contactperson GetContactperson(int contactperson_Id)
        {
            throw new System.NotImplementedException();
        }

        public Contactperson GetContactpersonTCLOAN(int contactperson_Id)
        {
            throw new System.NotImplementedException();
        }

        public List<Contactperson> GetContactpersons()
        {
            throw new System.NotImplementedException();
        }

        public List<Contactperson> GetContactpersonsTCLOAN()
        {
            throw new System.NotImplementedException();
        }

        public List<Contactperson> GetContactpersonsByName(string name)
        {
            throw new System.NotImplementedException();
        }

        public List<Customers> GetPartners()
        {
            throw new System.NotImplementedException();
        }

        public Customer GetPartner(int partner_Id)
        {
            throw new System.NotImplementedException();
        }

        public List<Report> GetReports()
        {
            throw new System.NotImplementedException();
        }

        public Report GetReport(int report_Id)
        {
            throw new System.NotImplementedException();
        }

        public Report GetReportFromYearAndMonth(string year, string month)
        {
            throw new System.NotImplementedException();
        }

        public void AddTask(Task task)
        {
            throw new System.NotImplementedException();
        }

        public void AddReport(Report report)
        {
            throw new System.NotImplementedException();
        }

        public void AddTasksToReport(List<Task> tasks, Report report)
        {
            throw new System.NotImplementedException();
        }

        public void AddCustomersToTask(List<Customer> customers, Task task)
        {
            throw new System.NotImplementedException();
        }

        public void AddCustomersToTaskWithId(List<Customer> customers, int task_Id)
        {
            throw new System.NotImplementedException();
        }

        public void RemoveCustomersFromTask(List<Customer> customers, Task task)
        {
            throw new System.NotImplementedException();
        }

        public void AddContactpersonsToTask(List<Customer> contactpersons, Task task)
        {
            throw new System.NotImplementedException();
        }

        public void AddContactpersonsToTaskWithId(List<Contactperson> contactpersons, int task_IId)
        {
            throw new System.NotImplementedException();
        }

        public void RemoveContactpersonsFromTask(List<Contactperson> contactpersons, Task task)
        {
            throw new System.NotImplementedException();
        }

        public void AddContactpersonsToCustomerWithId(List<Contactperson> contactpersons, Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public void RemoveContactpersonsFromCustomer(List<Contactperson> contactpersons, Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public void AddContactpersonsToCustomer(List<Contactperson> contactpersons, Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public void AddCustomerToTask(Customer customer, Task task)
        {
            throw new System.NotImplementedException();
        }

        public void AddContactpersonToTask(Contactperson contactperson, Task task)
        {
            throw new System.NotImplementedException();
        }

        public bool CheckReportExcistence(string year, string month)
        {
            throw new System.NotImplementedException();
        }

        public void AddUser(User user)
        {
            throw new System.NotImplementedException();
        }

        public void AddCustomer(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public void AddCustomerStart(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public void AddPartner(Customer customer)
        {
            throw new System.NotImplementedException();
        }

        public void AddContactperson(Contactperson contactperson)
        {
            throw new System.NotImplementedException();
        }

        public void EditTask(Task task, int task_Id)
        {
            throw new System.NotImplementedException();
        }

        public void EditCustomer(Customer customer, int customer_Id)
        {
            throw new System.NotImplementedException();
        }

        public void EditPartner(Customer customer, int partner_Id)
        {
            throw new System.NotImplementedException();
        }

        public User GetUser(string username, string password)
        {
            throw new System.NotImplementedException();
        }

        public void EditUserPassword(string password)
        {
            throw new System.NotImplementedException();
        }

        public DatabaseHandler GetInstance()
        {
            throw new System.NotImplementedException();
        }
    }
}