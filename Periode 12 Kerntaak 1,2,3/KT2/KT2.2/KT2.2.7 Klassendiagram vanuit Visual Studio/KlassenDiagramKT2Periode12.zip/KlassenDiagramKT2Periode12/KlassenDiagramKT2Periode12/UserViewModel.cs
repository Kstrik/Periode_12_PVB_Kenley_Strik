﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class UserViewModel
    {
        public UserViewModel()
        {
            throw new System.NotImplementedException();
        }

        public UserViewModel(User User, bool RememberPassword)
        {
            throw new System.NotImplementedException();
        }

        public User User
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public bool RememberPassword
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}