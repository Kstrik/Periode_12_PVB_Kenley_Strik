﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class Contactperson
    {
        public Contactperson()
        {
            throw new System.NotImplementedException();
        }

        public Contactperson(string Name, string Email, string Telephonenumber, bool Accountmanager)
        {
            throw new System.NotImplementedException();
        }

        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Name
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Email
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Telephonenumber
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public bool Accountmanager
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}