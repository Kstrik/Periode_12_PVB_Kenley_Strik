﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class IsAuthorized
    {
        public string[] Roles
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            throw new System.NotImplementedException();
        }
    }
}