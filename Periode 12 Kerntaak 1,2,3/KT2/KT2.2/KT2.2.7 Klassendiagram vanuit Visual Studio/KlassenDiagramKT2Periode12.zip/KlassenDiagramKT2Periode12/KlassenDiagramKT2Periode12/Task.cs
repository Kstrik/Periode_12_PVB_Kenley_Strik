﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class Task
    {
        public Task()
        {
            throw new System.NotImplementedException();
        }

        public Task(string Description, string Date, int Visit, int Research, int Conference_call, string Status)
        {
            throw new System.NotImplementedException();
        }

        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Description
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public DateTime Date
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int Visit
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int Research
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int Conference_call
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Status
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}