﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class User
    {
        public User()
        {
            throw new System.NotImplementedException();
        }

        public User(string Username, string Password, string Email, string Role)
        {
            throw new System.NotImplementedException();
        }

        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Username
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Password
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Email
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Role
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}