﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class UtilityHelper
    {
        public UtilityHelper()
        {
            throw new System.NotImplementedException();
        }

        public string GetHshedValue(string input)
        {
            throw new System.NotImplementedException();
        }
    }
}