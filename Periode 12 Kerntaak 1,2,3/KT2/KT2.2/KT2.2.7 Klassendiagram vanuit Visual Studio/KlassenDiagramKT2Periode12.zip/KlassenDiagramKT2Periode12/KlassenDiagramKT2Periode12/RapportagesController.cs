﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class RapportagesController
    {
        public DatabaseHandler DatabaseHandler
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public IsAuthorized IsAuthorized
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public ActionResult RappotageOpzetten()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult RapportageOpzetten(List<Task> tasks)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult RapportageInzien()
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetReport(string year, string month)
        {
            throw new System.NotImplementedException();
        }

        public JsonResult GetTasksFromYearAndMonth(string year, string month)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult ShowReport(string reportId)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult RapportgaeBekijken()
        {
            throw new System.NotImplementedException();
        }
    }
}