﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlassenDiagramKT2Periode12
{
    public class LoginController
    {
        public DatabaseHandler DatabaseHandler
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public UtilityHelper UtilityHelper
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public ActionResult Login()
        {
            throw new System.NotImplementedException();
        }

        public ActionResult Login(UserViewModel userViewModel)
        {
            throw new System.NotImplementedException();
        }

        public ActionResult Logout()
        {
            throw new System.NotImplementedException();
        }
    }
}